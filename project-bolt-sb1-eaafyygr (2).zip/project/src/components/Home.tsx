import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from './ui/Button';
import { useStore } from '../store/useStore';
import { StandardsGrid } from '../features/standards/components/StandardsGrid';
import { Search, ShoppingCart } from 'lucide-react';
import { Logo } from './Logo';

export function Home() {
  const { user, standards, cart } = useStore();
  const [searchTerm, setSearchTerm] = React.useState('');

  const filteredStandards = standards.filter(standard => 
    standard.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    standard.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    standard.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="text-center py-12">
        <div className="flex justify-center mb-6">
          <Logo size="lg" />
        </div>
        <h1 className="text-4xl font-bold text-primary mb-6">
          SSMO Standards Store
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Access, purchase, and download Sudanese standards with ease
        </p>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <input
              type="search"
              placeholder="Search standards by title, number, or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <div className="max-w-md mx-auto mb-8 bg-white p-4 rounded-lg shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5 text-primary" />
                <span className="font-medium">
                  {cart.length} {cart.length === 1 ? 'item' : 'items'} in cart
                </span>
              </div>
              <Link to="/cart">
                <Button size="sm">
                  View Cart
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Standards Grid */}
      {searchTerm && (
        <div className="px-4 mb-12">
          <h2 className="text-2xl font-bold mb-6">Search Results</h2>
          {filteredStandards.length > 0 ? (
            <StandardsGrid standards={filteredStandards} />
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow">
              <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No standards found</h3>
              <p className="text-gray-500">
                Try adjusting your search terms or browse all standards
              </p>
            </div>
          )}
        </div>
      )}

      {/* Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 mb-12">
        <FeatureCard
          title="Browse Standards"
          description="Search and filter through our comprehensive collection of standards"
          icon="🔍"
        />
        <FeatureCard
          title="Secure Purchase"
          description="Multiple payment options with secure checkout process"
          icon="🔒"
        />
        <FeatureCard
          title="Instant Access"
          description="Download standards immediately after purchase"
          icon="⚡"
        />
      </div>
    </div>
  );
}

function FeatureCard({ title, description, icon }: { title: string; description: string; icon: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-primary mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}