import React from 'react';
import { formatPrice } from '../lib/utils';
import { Standard } from '../types';
import { FileText, ShoppingCart, Check } from 'lucide-react';
import { useStore } from '../store/useStore';
import { Button } from './ui/Button';

interface StandardCardProps {
  standard: Standard;
}

export function StandardCard({ standard }: StandardCardProps) {
  const { addToCart, cart, user } = useStore();
  const inCart = cart.some(item => item.standardId === standard.id);
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{standard.title}</h3>
            <p className="text-sm text-gray-500">Standard No: {standard.number}</p>
          </div>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {standard.complianceType}
          </span>
        </div>

        <p className="mt-2 text-sm text-gray-600 line-clamp-2">{standard.description}</p>

        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-bold text-gray-900">{formatPrice(standard.price)}</span>
          {!isAdmin && (
            <Button
              onClick={() => !inCart && addToCart(standard.id)}
              disabled={inCart}
              className={inCart ? 'bg-green-600' : ''}
            >
              {inCart ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  In Cart
                </>
              ) : (
                <>
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </>
              )}
            </Button>
          )}
        </div>

        <div className="mt-4 flex items-center text-sm text-gray-500">
          <FileText className="h-4 w-4 mr-1" />
          <span>Released: {new Date(standard.releaseDate).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
}