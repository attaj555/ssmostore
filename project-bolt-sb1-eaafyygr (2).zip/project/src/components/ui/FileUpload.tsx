import React, { useRef, useState } from 'react';
import { Upload, X, FileText, Check, Image } from 'lucide-react';
import { Button } from './Button';

interface FileUploadProps {
  onChange: (file: File | null) => void;
  value?: File | null;
  currentFileName?: string;
  accept?: string;
  maxSize?: number; // in MB
  allowedTypes?: ('image' | 'pdf')[];
}

export function FileUpload({
  onChange,
  value,
  currentFileName,
  accept = '.pdf,.jpg,.jpeg,.png',
  maxSize = 10,
  allowedTypes = ['image', 'pdf']
}: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);

  const validateFile = (file: File): boolean => {
    setError('');
    const sizeInMB = file.size / (1024 * 1024);

    if (sizeInMB > maxSize) {
      setError(`File size must be less than ${maxSize}MB`);
      return false;
    }

    const isImage = file.type.startsWith('image/');
    const isPDF = file.type === 'application/pdf';

    if (!allowedTypes.includes('image') && isImage) {
      setError('Images are not allowed');
      return false;
    }

    if (!allowedTypes.includes('pdf') && isPDF) {
      setError('PDF files are not allowed');
      return false;
    }

    if (!isImage && !isPDF) {
      setError(`Only ${allowedTypes.join(' and ')} files are allowed`);
      return false;
    }

    return true;
  };

  const handleFileChange = (files: FileList | null) => {
    setError('');
    if (!files?.length) return;

    const file = files[0];
    if (validateFile(file)) {
      onChange(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  };

  const clearFile = () => {
    onChange(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const getFileIcon = (file: File | null) => {
    if (!file) return null;
    return file.type.startsWith('image/') ? <Image className="h-5 w-5 text-primary" /> : <FileText className="h-5 w-5 text-primary" />;
  };

  return (
    <div className="space-y-2">
      <div
        className={`border-2 border-dashed rounded-lg p-4 transition-colors cursor-pointer ${
          isDragging
            ? 'border-primary bg-primary/5'
            : 'border-gray-300 hover:border-primary'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
      >
        <input
          type="file"
          ref={inputRef}
          accept={accept}
          onChange={(e) => handleFileChange(e.target.files)}
          className="hidden"
        />

        {value || currentFileName ? (
          <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
            <div className="flex items-center space-x-2">
              {getFileIcon(value)}
              <span className="text-sm font-medium">
                {value?.name || currentFileName}
              </span>
              <Check className="h-4 w-4 text-green-500" />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                clearFile();
              }}
              className="text-red-500 hover:text-red-700"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="text-center">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="mt-4 flex text-sm leading-6 text-gray-600">
              <label className="relative cursor-pointer rounded-md bg-white font-semibold text-primary focus-within:outline-none focus-within:ring-2 focus-within:ring-primary">
                <span>Upload a file</span>
                <span className="pl-1">or drag and drop</span>
              </label>
            </div>
            <p className="text-xs text-gray-500">
              {allowedTypes.includes('image') && allowedTypes.includes('pdf')
                ? 'Images or PDF'
                : allowedTypes.includes('image')
                ? 'Images only'
                : 'PDF only'} (up to {maxSize}MB)
            </p>
          </div>
        )}
      </div>

      {error && (
        <p className="text-sm text-red-500 mt-1">{error}</p>
      )}
    </div>
  );
}