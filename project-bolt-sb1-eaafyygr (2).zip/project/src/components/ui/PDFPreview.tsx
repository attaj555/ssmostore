import React, { useState } from 'react';
import { FileText, Download, Eye, X } from 'lucide-react';
import { Button } from './Button';
import { downloadStandardPDF } from '../../lib/storage/fileStorage';

interface PDFPreviewProps {
  url?: string;
  fileName: string;
  showPreview?: boolean;
  onPreview?: () => void;
}

export function PDFPreview({ url, fileName, showPreview = true, onPreview }: PDFPreviewProps) {
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  if (!url) {
    return (
      <span className="text-gray-400 italic text-sm">No PDF available</span>
    );
  }

  const handleDownload = async () => {
    try {
      if (url) {
        await downloadStandardPDF(url, fileName);
      }
    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download the PDF. Please try again.');
    }
  };

  const handlePreview = () => {
    if (onPreview) {
      onPreview();
    } else {
      setIsPreviewOpen(true);
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <Button
        size="sm"
        variant="outline"
        onClick={handleDownload}
        title="Download PDF"
        className="text-blue-600 hover:text-blue-700"
      >
        <Download className="h-4 w-4" />
      </Button>
      
      {showPreview && (
        <>
          <Button
            size="sm"
            variant="outline"
            onClick={handlePreview}
            title="Preview PDF"
            className="text-green-600 hover:text-green-700"
          >
            <Eye className="h-4 w-4" />
          </Button>

          {isPreviewOpen && (
            <div className="fixed inset-0 z-50 overflow-hidden bg-black bg-opacity-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg w-full max-w-4xl h-[90vh] flex flex-col">
                <div className="flex justify-between items-center p-4 border-b">
                  <div className="flex items-center space-x-2">
                    <FileText className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">{fileName}</h3>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setIsPreviewOpen(false)}
                    className="text-gray-600 hover:text-gray-700"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex-1 bg-gray-100 p-4">
                  <object
                    data={url}
                    type="application/pdf"
                    className="w-full h-full rounded border border-gray-200"
                  >
                    <div className="flex flex-col items-center justify-center h-full bg-white rounded p-8 text-center">
                      <FileText className="h-12 w-12 text-gray-400 mb-4" />
                      <p className="text-gray-600 mb-4">
                        Unable to display PDF preview. You can download the file to view it.
                      </p>
                      <Button onClick={handleDownload}>
                        <Download className="h-4 w-4 mr-2" />
                        Download PDF
                      </Button>
                    </div>
                  </object>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}