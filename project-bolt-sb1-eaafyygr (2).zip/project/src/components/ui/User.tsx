import React from 'react';
import { UserIcon } from 'lucide-react';
import { UserRole } from '../../types';

interface UserProps {
  name: string;
  email: string;
  role: UserRole;
  createdAt: string;
}

export function User({ name, email, role, createdAt }: UserProps) {
  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return 'Super Admin';
      case 'admin':
        return 'Admin';
      default:
        return 'User';
    }
  };

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return 'bg-purple-100 text-purple-800';
      case 'admin':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="flex items-center space-x-4">
      <div className="bg-primary/10 p-3 rounded-full">
        <UserIcon className="h-8 w-8 text-primary" />
      </div>
      <div>
        <div className="flex items-center space-x-2">
          <h3 className="font-medium text-lg">{name}</h3>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleColor(role)}`}>
            {getRoleLabel(role)}
          </span>
        </div>
        <p className="text-gray-500">{email}</p>
        <p className="text-sm text-gray-400">
          Member since {new Date(createdAt).toLocaleDateString()}
        </p>
      </div>
    </div>
  );
}