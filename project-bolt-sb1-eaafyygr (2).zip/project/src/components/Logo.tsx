import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function Logo({ className = '', size = 'md' }: LogoProps) {
  const sizes = {
    sm: { width: 'w-12', height: 'h-8' },
    md: { width: 'w-16', height: 'h-12' },
    lg: { width: 'w-24', height: 'h-16' },
  };

  return (
    <Link to="/" className={`block ${className}`}>
      <div className={`relative ${sizes[size].width} ${sizes[size].height}`}>
        {/* White border */}
        <div className="absolute inset-0 bg-white rounded-[60%] transform scale-x-[1.6]" />
        
        {/* Outer golden ring */}
        <div className="absolute inset-[2px] bg-[#F4A460] rounded-[60%] transform scale-x-[1.6]" />
        
        {/* Inner white ring */}
        <div className="absolute inset-[15%] bg-white rounded-[60%] transform scale-x-[1.6]" />
        
        {/* Navy blue center */}
        <div className="absolute inset-[17%] bg-[#000080] rounded-[60%] transform scale-x-[1.6] flex items-center justify-center">
          <span 
            className="text-white font-bold tracking-wider transform scale-x-[0.625]" 
            style={{ 
              fontSize: size === 'sm' ? '0.75rem' : size === 'md' ? '1rem' : '1.25rem'
            }}
          >
            SSMO
          </span>
        </div>
      </div>
    </Link>
  );
}