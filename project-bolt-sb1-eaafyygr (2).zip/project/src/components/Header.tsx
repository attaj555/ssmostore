import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User as UserIcon, Search, LogOut } from 'lucide-react';
import { useStore } from '../store/useStore';
import { Button } from './ui/Button';
import { Logo } from './Logo';

export function Header() {
  const { user, cart, setUser } = useStore();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleLogout = () => {
    setUser(null);
    navigate('/login');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/standards?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery(''); // Clear search after navigation
    }
  };

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  return (
    <header className="bg-[#003366] text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Logo size="md" />
            <Link to="/" className="text-2xl font-bold hover:text-[#FFD700] transition">
              Standards Store
            </Link>
          </div>

          <div className="flex items-center space-x-8">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="search"
                placeholder="Search standards..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 rounded-lg bg-white/10 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/20 w-64"
              />
              <button type="submit" className="absolute left-3 top-2.5 text-white/70 hover:text-white">
                <Search className="h-5 w-5" />
              </button>
            </form>

            <nav className="flex items-center space-x-6">
              <Link to="/standards" className="hover:text-[#FFD700] transition">
                Browse
              </Link>
              
              {/* Only show cart for non-admin users */}
              {!isAdmin && (
                <Link to="/cart" className="relative hover:text-[#FFD700] transition">
                  <ShoppingCart className="h-6 w-6" />
                  {cart.length > 0 && (
                    <span className="absolute -top-2 -right-2 bg-[#FFD700] text-[#003366] text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {cart.length}
                    </span>
                  )}
                </Link>
              )}

              {user ? (
                <div className="flex items-center space-x-4">
                  <Link 
                    to={isAdmin ? "/admin" : "/profile"} 
                    className="hover:text-[#FFD700] transition flex items-center space-x-2"
                  >
                    <UserIcon className="h-6 w-6" />
                    <span className="text-sm font-medium">{user.name}</span>
                  </Link>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="text-white border-white hover:bg-white/10"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Link to="/login" className="hover:text-[#FFD700] transition">
                  <UserIcon className="h-6 w-6" />
                </Link>
              )}
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
}