import { Standard } from '../../types';

class StandardsCache {
  private static instance: StandardsCache;
  private cache: Map<string, { data: Standard; timestamp: number }> = new Map();
  private readonly TTL = 5 * 60 * 1000; // 5 minutes

  private constructor() {}

  public static getInstance(): StandardsCache {
    if (!StandardsCache.instance) {
      StandardsCache.instance = new StandardsCache();
    }
    return StandardsCache.instance;
  }

  set(standard: Standard): void {
    this.cache.set(standard.id, {
      data: standard,
      timestamp: Date.now(),
    });
  }

  get(id: string): Standard | null {
    const cached = this.cache.get(id);
    if (!cached) return null;
    
    if (Date.now() - cached.timestamp > this.TTL) {
      this.cache.delete(id);
      return null;
    }
    
    return cached.data;
  }

  invalidate(id: string): void {
    this.cache.delete(id);
  }

  clear(): void {
    this.cache.clear();
  }
}

export const standardsCache = StandardsCache.getInstance();