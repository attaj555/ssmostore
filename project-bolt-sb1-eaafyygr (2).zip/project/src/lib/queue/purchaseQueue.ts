interface PurchaseJob {
  id: string;
  userId: string;
  standardIds: string[];
  timestamp: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  retries: number;
}

class PurchaseQueue {
  private static instance: PurchaseQueue;
  private queue: PurchaseJob[] = [];
  private processing = false;
  private readonly MAX_RETRIES = 3;
  private readonly PROCESS_INTERVAL = 1000; // 1 second

  private constructor() {
    this.startProcessing();
  }

  public static getInstance(): PurchaseQueue {
    if (!PurchaseQueue.instance) {
      PurchaseQueue.instance = new PurchaseQueue();
    }
    return PurchaseQueue.instance;
  }

  async add(userId: string, standardIds: string[]): Promise<string> {
    const jobId = Math.random().toString(36).substring(2);
    this.queue.push({
      id: jobId,
      userId,
      standardIds,
      timestamp: Date.now(),
      status: 'pending',
      retries: 0,
    });
    return jobId;
  }

  private async startProcessing() {
    if (this.processing) return;
    this.processing = true;

    while (true) {
      const job = this.queue.find(j => j.status === 'pending');
      if (job) {
        try {
          job.status = 'processing';
          // Process purchase logic here
          await this.processPurchase(job);
          job.status = 'completed';
        } catch (error) {
          if (job.retries < this.MAX_RETRIES) {
            job.retries++;
            job.status = 'pending';
          } else {
            job.status = 'failed';
          }
        }
      }
      
      // Clean up completed/failed jobs older than 1 hour
      const oneHourAgo = Date.now() - 60 * 60 * 1000;
      this.queue = this.queue.filter(
        j => j.status === 'pending' || j.status === 'processing' || j.timestamp > oneHourAgo
      );

      await new Promise(resolve => setTimeout(resolve, this.PROCESS_INTERVAL));
    }
  }

  private async processPurchase(job: PurchaseJob): Promise<void> {
    // Implement actual purchase processing logic here
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate processing time
  }

  getStatus(jobId: string): string {
    const job = this.queue.find(j => j.id === jobId);
    return job?.status || 'not_found';
  }
}

export const purchaseQueue = PurchaseQueue.getInstance();