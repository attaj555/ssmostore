import { PaymentDetails } from './types';
import { BANK_TRANSFER_PROVIDERS } from './providers';

export function validatePaymentDetails(details: PaymentDetails): { isValid: boolean; error?: string } {
  // Validate payment amount
  if (typeof details.amount !== 'number' || isNaN(details.amount) || details.amount <= 0) {
    return { isValid: false, error: 'Invalid payment amount' };
  }

  // Validate currency
  if (!details.currency || !['SDG', 'USD'].includes(details.currency)) {
    return { isValid: false, error: 'Invalid currency' };
  }

  if (details.method === 'bank_transfer') {
    // Validate bank account number format
    if (!details.accountNumber) {
      return { isValid: false, error: 'Account number is required' };
    }

    // Check if account number matches the selected bank's format
    const bank = BANK_TRANSFER_PROVIDERS.find(b => b.id === details.bankId);
    if (!bank) {
      return { isValid: false, error: 'Invalid bank selected' };
    }

    // Validate account number format based on bank
    const accountNumberRegex = /^\d{10,16}$/; // 10-16 digits
    if (!accountNumberRegex.test(details.accountNumber)) {
      return { 
        isValid: false, 
        error: 'Account number must be between 10-16 digits'
      };
    }

    // Validate reference number
    if (!details.referenceNumber) {
      return { isValid: false, error: 'Reference number is required' };
    }

    const referenceRegex = /^[A-Z0-9]{8,}$/i;
    if (!referenceRegex.test(details.referenceNumber)) {
      return { 
        isValid: false, 
        error: 'Reference number must be at least 8 alphanumeric characters'
      };
    }

    // Validate payer information
    if (!details.payerName?.trim()) {
      return { isValid: false, error: 'Payer name is required' };
    }

    if (!details.payerPhone) {
      return { isValid: false, error: 'Phone number is required' };
    }

    // Validate Sudanese phone number format
    const phoneRegex = /^(\+249|0)?[0-9]{9}$/;
    if (!phoneRegex.test(details.payerPhone)) {
      return { 
        isValid: false, 
        error: 'Invalid phone number format. Use format: +249XXXXXXXXX or 0XXXXXXXXX'
      };
    }

    // Validate payment date
    if (!details.paymentDate) {
      return { isValid: false, error: 'Payment date is required' };
    }

    const paymentDate = new Date(details.paymentDate);
    const now = new Date();
    const sevenDaysAgo = new Date(now.setDate(now.getDate() - 7));

    if (paymentDate > new Date()) {
      return { isValid: false, error: 'Payment date cannot be in the future' };
    }

    if (paymentDate < sevenDaysAgo) {
      return { isValid: false, error: 'Payment must be within the last 7 days' };
    }
  }

  return { isValid: true };
}