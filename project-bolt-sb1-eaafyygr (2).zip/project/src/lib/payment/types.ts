export interface BankAccount {
  id: string;
  bankId: string;
  accountNumber: string;
  accountName: string;
  branch: string;
  isActive: boolean;
  lastUpdated: string;
  updatedBy: string;
}

export interface Bank {
  id: string;
  name: string;
  code: string;
  logo: string;
  accounts: BankAccount[];
}

export type PaymentMethod = 'bank_transfer' | 'local_card' | 'international_card';

export interface PaymentDetails {
  method: PaymentMethod;
  amount: number;
  currency: 'SDG' | 'USD';
  bankId?: string;
  accountNumber?: string;
  referenceNumber?: string;
  payerName?: string;
  payerPhone?: string;
  paymentDate?: string;
  cardType?: string;
  cardNumber?: string;
  cardExpiry?: string;
  cardCvc?: string;
  cardHolderName?: string;
}