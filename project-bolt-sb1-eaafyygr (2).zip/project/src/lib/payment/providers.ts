import { PaymentProvider } from './types';

export const LOCAL_CARD_PROVIDERS: PaymentProvider[] = [
  {
    id: 'bok_card',
    name: 'Bank of Khartoum Card',
    type: 'local_card',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/bok-logo.png',
    currencies: ['SDG'],
    enabled: true,
  },
  {
    id: 'onb_card',
    name: 'Omdurman National Bank Card',
    type: 'local_card',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/onb-logo.png',
    currencies: ['SDG'],
    enabled: true,
  },
  {
    id: 'fib_card',
    name: 'Faisal Islamic Bank Card',
    type: 'local_card',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/fib-logo.png',
    currencies: ['SDG'],
    enabled: true,
  },
];

export const INTERNATIONAL_CARD_PROVIDERS: PaymentProvider[] = [
  {
    id: 'mastercard',
    name: 'Mastercard',
    type: 'international_card',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/mastercard-logo.png',
    currencies: ['USD', 'SDG'],
    enabled: true,
  },
  {
    id: 'paypal',
    name: 'PayPal',
    type: 'international_card',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/paypal-logo.png',
    currencies: ['USD'],
    enabled: true,
  },
];

export const BANK_TRANSFER_PROVIDERS = [
  {
    id: 'bok',
    name: 'Bank of Khartoum',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/bok-logo.png',
    accountNumber: '0000123456789',
    branch: 'Main Branch',
  },
  {
    id: 'onb',
    name: 'Omdurman National Bank',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/onb-logo.png',
    accountNumber: '0000987654321',
    branch: 'Omdurman Branch',
  },
  {
    id: 'fib',
    name: 'Faisal Islamic Bank',
    logo: 'https://raw.githubusercontent.com/yourusername/yourrepo/main/public/payment/fib-logo.png',
    accountNumber: '0000456789123',
    branch: 'Khartoum Branch',
  },
];