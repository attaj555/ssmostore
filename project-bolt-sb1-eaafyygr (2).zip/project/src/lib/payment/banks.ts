import { Bank } from './types';

export const SUPPORTED_BANKS: Bank[] = [
  {
    id: 'bok',
    name: 'Bank of Khartoum',
    code: 'BOK',
    logo: '/banks/bok-logo.png',
    accounts: [
      {
        bankId: 'bok',
        accountNumber: '0000123456789',
        accountName: 'SSMO Standards Store',
        branch: 'Main Branch',
      }
    ]
  },
  {
    id: 'onb',
    name: 'Omdurman National Bank',
    code: 'ONB',
    logo: '/banks/onb-logo.png',
    accounts: [
      {
        bankId: 'onb',
        accountNumber: '0000987654321',
        accountName: 'SSMO Standards Store',
        branch: 'Omdurman Branch',
      }
    ]
  },
  {
    id: 'fib',
    name: 'Faisal Islamic Bank',
    code: 'FIB',
    logo: '/banks/fib-logo.png',
    accounts: [
      {
        bankId: 'fib',
        accountNumber: '0000456789123',
        accountName: 'SSMO Standards Store',
        branch: 'Khartoum Branch',
      }
    ]
  }
];