// Card number patterns
const CARD_PATTERNS = {
  visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
  mastercard: /^(5[1-5][0-9]{14}|2[2-7][0-9]{14})$/,
  amex: /^3[47][0-9]{13}$/,
  discover: /^6(?:011|5[0-9]{2})[0-9]{12}$/,
  paypal: /^paypal$/i,
};

// Card logos from trusted CDN
export const CARD_LOGOS = {
  visa: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/visa.svg',
  mastercard: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/mastercard.svg',
  amex: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/amex.svg',
  discover: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/discover.svg',
  paypal: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/paypal.svg',
  unknown: 'https://cdn.jsdelivr.net/npm/payment-icons/min/flat/default.svg',
};

export type CardType = keyof typeof CARD_PATTERNS | 'unknown';

export function detectCardType(cardNumber: string): CardType {
  // Remove spaces and dashes
  const cleanNumber = cardNumber.replace(/[\s-]/g, '');
  
  // Check each pattern
  for (const [type, pattern] of Object.entries(CARD_PATTERNS)) {
    if (pattern.test(cleanNumber)) {
      return type as CardType;
    }
  }
  
  return 'unknown';
}

export function formatCardNumber(value: string): string {
  const cleanValue = value.replace(/\D+/g, '');
  const chunks = [];
  
  for (let i = 0; i < cleanValue.length; i += 4) {
    chunks.push(cleanValue.slice(i, i + 4));
  }
  
  return chunks.join(' ');
}

export function validateCardNumber(cardNumber: string): boolean {
  const cleanNumber = cardNumber.replace(/\D+/g, '');
  
  // Check if empty or not a number
  if (!cleanNumber || isNaN(Number(cleanNumber))) {
    return false;
  }
  
  // Luhn algorithm implementation
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost one
  for (let i = cleanNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanNumber.charAt(i));

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0 && cleanNumber.length >= 13 && cleanNumber.length <= 19;
}