export function validateAdminEmail(email: string): { isValid: boolean; error?: string } {
  // Allow attaj555@gmail.com as a special case
  if (email === 'attaj555@gmail.com') {
    return { isValid: true };
  }

  // Check if email ends with @ssmo.gov.sd
  if (!email.toLowerCase().endsWith('@ssmo.gov.sd')) {
    return {
      isValid: false,
      error: 'Admin email must be a valid SSMO email address (@ssmo.gov.sd)',
    };
  }

  return { isValid: true };
}