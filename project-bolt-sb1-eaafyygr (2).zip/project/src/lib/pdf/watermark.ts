import { jsPDF } from 'jspdf';

export async function addWatermark(pdfFile: File, buyerName: string): Promise<Blob> {
  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const pdfData = e.target?.result as ArrayBuffer;
        const doc = new jsPDF();
        
        // Add watermark on each page
        doc.setFontSize(60);
        doc.setTextColor(200, 200, 200); // Light gray
        doc.setGState(new doc.GState({ opacity: 0.3 }));
        
        const watermarkText = `Purchased by: ${buyerName}`;
        const pageWidth = doc.internal.pageSize.width;
        const pageHeight = doc.internal.pageSize.height;
        
        // Add diagonal watermark
        doc.saveGraphicsState();
        doc.translate(pageWidth/2, pageHeight/2);
        doc.rotate(-45);
        doc.text(watermarkText, -doc.getTextWidth(watermarkText)/2, 0);
        doc.restoreGraphicsState();
        
        // Add footer with timestamp
        doc.setFontSize(8);
        doc.setTextColor(128, 128, 128);
        const timestamp = new Date().toLocaleString();
        doc.text(`Downloaded on: ${timestamp}`, 10, pageHeight - 10);
        
        // Convert to blob
        const watermarkedPdf = doc.output('blob');
        resolve(watermarkedPdf);
      };
      reader.onerror = () => reject(new Error('Failed to read PDF file'));
      reader.readAsArrayBuffer(pdfFile);
    } catch (error) {
      reject(error);
    }
  });
}