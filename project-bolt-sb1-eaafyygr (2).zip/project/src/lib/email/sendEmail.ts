import { CartItem, Standard } from '../../types';

interface PurchaseDetails {
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  items: (CartItem & { standard: Standard })[];
  total: number;
  billingAddress: {
    company?: string;
    address: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
}

export async function sendPurchaseConfirmation(details: PurchaseDetails) {
  // In a real app, this would send an actual email
  console.log('Sending purchase confirmation email to:', details.customerEmail);
  console.log('Purchase Details:', {
    orderNumber: details.orderNumber,
    customerName: details.customerName,
    items: details.items.map(item => ({
      title: item.standard.title,
      quantity: item.quantity,
      price: item.standard.price * item.quantity,
    })),
    total: details.total,
    billingAddress: details.billingAddress,
  });
}