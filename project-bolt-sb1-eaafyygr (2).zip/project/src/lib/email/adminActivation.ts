import { User } from '../../types';

interface ActivationEmailData {
  name: string;
  email: string;
  activationToken: string;
  activationUrl: string;
}

export async function sendActivationEmail(data: ActivationEmailData) {
  // In a real app, this would send an actual email
  // For demo purposes, we'll log the email content
  console.log('Sending activation email to:', data.email);
  console.log('Activation URL:', data.activationUrl);
  
  // Mock email template
  const emailContent = `
    Dear ${data.name},

    You have been added as an admin to the SSMO Standards Store.
    Please click the link below to activate your account and set your password:

    ${data.activationUrl}

    This link will expire in 24 hours.

    Best regards,
    SSMO Standards Store Team
  `;

  console.log('Email content:', emailContent);
  return Promise.resolve(true);
}