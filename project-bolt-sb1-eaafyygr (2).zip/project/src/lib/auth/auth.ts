import { User, UserRole } from '../../types';
import { superAdmins } from '../../store/data/users';
import { useStore } from '../../store/useStore';

interface LoginResult {
  success: boolean;
  error?: string;
  user?: User;
}

export async function authenticateUser(email: string, password: string): Promise<LoginResult> {
  // Get store instance to check approved admins
  const store = useStore.getState();
  
  // Check for super admins first
  const superAdmin = superAdmins.find(admin => admin.email.toLowerCase() === email.toLowerCase());
  if (superAdmin) {
    if (password === '123') { // In production, use proper password verification
      return {
        success: true,
        user: superAdmin
      };
    }
    return {
      success: false,
      error: 'Invalid password'
    };
  }

  // Check if it's an approved admin
  const approvedAdmin = store.admins.find(admin => admin.email.toLowerCase() === email.toLowerCase());
  if (approvedAdmin) {
    if (password === '123') { // In production, use proper password verification
      return {
        success: true,
        user: approvedAdmin
      };
    }
    return {
      success: false,
      error: 'Invalid password'
    };
  }

  // Regular user login
  if (email && password) {
    // Don't allow @ssmo.gov.sd emails unless they're approved admins
    if (email.toLowerCase().endsWith('@ssmo.gov.sd')) {
      return {
        success: false,
        error: 'Please contact a super admin to get admin access'
      };
    }

    return {
      success: true,
      user: {
        id: Math.random().toString(36).substr(2, 9),
        name: email.split('@')[0],
        email,
        role: 'user',
        createdAt: new Date().toISOString(),
      }
    };
  }

  return {
    success: false,
    error: 'Invalid email or password'
  };
}