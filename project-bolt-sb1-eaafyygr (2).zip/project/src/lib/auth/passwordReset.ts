import { validateAdminEmail } from '../validation/adminValidation';
import { useStore } from '../../store/useStore';

export async function sendPasswordResetEmail(email: string): Promise<void> {
  const store = useStore.getState();
  const isAdmin = email.toLowerCase().endsWith('@ssmo.gov.sd');
  const isSuperAdmin = email === 'attaj555@gmail.com' || email === 'storeadmin@ssmo.gov.sd';

  // Validate admin emails
  if (isAdmin && !isSuperAdmin) {
    const validation = validateAdminEmail(email);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }
  }

  // Generate reset token
  const token = Math.random().toString(36).substr(2) + Date.now().toString(36);
  const resetLink = `${window.location.origin}/reset-password/${token}`;

  // In a real app, this would send an actual email
  console.log('Password reset email sent to:', email);
  console.log('Reset link:', resetLink);

  // Store the reset token with expiration
  store.addPasswordResetToken(email, token);

  return Promise.resolve();
}

export async function verifyResetToken(token: string): Promise<boolean> {
  const store = useStore.getState();
  return store.verifyPasswordResetToken(token);
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  const store = useStore.getState();
  return store.resetPasswordWithToken(token, newPassword);
}