// In a real app, use a proper password hashing library like bcrypt
export async function hashPassword(password: string): Promise<string> {
  // This is just for demo purposes
  // In production, use proper password hashing
  return `hashed_${password}`;
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  // This is just for demo purposes
  // In production, use proper password verification
  return `hashed_${password}` === hashedPassword;
}