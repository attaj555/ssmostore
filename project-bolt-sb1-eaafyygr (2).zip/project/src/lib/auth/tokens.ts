export function generateActivationToken(): string {
  // Generate a random token
  const token = Math.random().toString(36).substr(2) + 
                Math.random().toString(36).substr(2) +
                Math.random().toString(36).substr(2);
  return token;
}