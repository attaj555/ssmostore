import { format, parseISO, isWithinInterval } from 'date-fns';
import { Standard } from '../../types';
import { ReportPeriod } from './types';

export function filterStandardsByPeriod(standards: Standard[], period: ReportPeriod): Standard[] {
  return standards.filter(standard => {
    if (!standard.releaseDate) return false;
    
    try {
      const standardDate = parseISO(standard.releaseDate);
      const startDate = parseISO(period.startDate);
      const endDate = parseISO(period.endDate);
      
      return isWithinInterval(standardDate, { start: startDate, end: endDate });
    } catch (error) {
      console.error('Date parsing error:', error);
      return false;
    }
  });
}

export function calculateCategoryStats(standards: Standard[]) {
  return {
    total: standards.length,
    mandatory: standards.filter(s => s.complianceType === 'mandatory').length,
    optional: standards.filter(s => s.complianceType === 'optional').length,
    averagePrice: standards.length > 0 
      ? standards.reduce((sum, s) => sum + s.price, 0) / standards.length 
      : 0,
    newest: standards.length > 0
      ? standards.reduce((newest, current) => 
          new Date(current.releaseDate) > new Date(newest.releaseDate) ? current : newest
        , standards[0])
      : null,
  };
}

export function formatDate(date: string | Date): string {
  try {
    const parsedDate = typeof date === 'string' ? parseISO(date) : date;
    return format(parsedDate, 'dd MMM yyyy');
  } catch (error) {
    console.error('Date formatting error:', error);
    return 'Invalid Date';
  }
}