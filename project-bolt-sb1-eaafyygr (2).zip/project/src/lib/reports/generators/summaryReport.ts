import { jsPDF } from 'jspdf';
import { ReportData } from '../types';
import { addHeader, addFooter } from './common';
import { formatPrice } from '../../utils';

export function generateSummaryReport(doc: jsPDF, data: ReportData & { allTime?: boolean }) {
  const { standards, stats } = data;
  const filteredStandards = data.allTime 
    ? standards
    : standards.filter(standard => !data.category || standard.category === data.category);

  // Summary statistics
  const summaryStats = [
    ['Total Standards', filteredStandards.length.toString()],
    ['Mandatory Standards', filteredStandards.filter(s => s.complianceType === 'mandatory').length.toString()],
    ['Total Categories', stats.categoriesCount.toString()],
    ['Average Price', formatPrice(filteredStandards.reduce((sum, s) => sum + s.price, 0) / filteredStandards.length || 0)],
  ];
  
  (doc as any).autoTable({
    startY: 75,
    head: [['Metric', 'Value']],
    body: summaryStats,
    theme: 'grid',
    headStyles: { fillColor: [0, 51, 102] },
  });

  return doc;
}