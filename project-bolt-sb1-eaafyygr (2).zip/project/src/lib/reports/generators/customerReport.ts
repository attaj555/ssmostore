import { jsPDF } from 'jspdf';
import { ReportData, CustomerPurchase } from '../types';
import { formatDate } from '../utils';
import { formatPrice } from '../../utils';

export function generateCustomerReport(doc: jsPDF, data: ReportData & { allTime?: boolean }) {
  if (!data.customerName || !data.purchases) return doc;

  const purchases = data.allTime 
    ? data.purchases
    : data.purchases.filter(purchase => {
        const purchaseDate = new Date(purchase.purchaseDate);
        return purchaseDate >= new Date(data.period.startDate) && 
               purchaseDate <= new Date(data.period.endDate);
      });

  // Customer statistics
  const totalSpent = purchases.reduce((sum, p) => sum + p.price, 0);
  const averageSpent = purchases.length > 0 ? totalSpent / purchases.length : 0;

  const customerStats = [
    ['Total Purchases', purchases.length.toString()],
    ['Total Spent', formatPrice(totalSpent)],
    ['Average Purchase', formatPrice(averageSpent)],
    ['First Purchase', purchases.length > 0 ? formatDate(purchases[0].purchaseDate) : 'N/A'],
    ['Latest Purchase', purchases.length > 0 ? formatDate(purchases[purchases.length - 1].purchaseDate) : 'N/A'],
  ];

  (doc as any).autoTable({
    startY: 75,
    head: [['Metric', 'Value']],
    body: customerStats,
    theme: 'grid',
    headStyles: { fillColor: [0, 51, 102] },
  });

  // Purchase history
  if (purchases.length > 0) {
    doc.setFontSize(14);
    doc.text('Purchase History', 14, (doc as any).lastAutoTable.finalY + 20);

    const purchaseData = purchases.map(p => {
      const standard = data.standards.find(s => s.id === p.standardId);
      return [
        formatDate(p.purchaseDate),
        standard?.number || 'N/A',
        standard?.title || 'N/A',
        formatPrice(p.price),
      ];
    });

    (doc as any).autoTable({
      startY: (doc as any).lastAutoTable.finalY + 25,
      head: [['Date', 'Standard No.', 'Title', 'Price']],
      body: purchaseData,
      theme: 'grid',
      headStyles: { fillColor: [0, 51, 102] },
    });
  }

  return doc;
}