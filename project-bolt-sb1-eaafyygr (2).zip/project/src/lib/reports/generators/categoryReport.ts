import { jsPDF } from 'jspdf';
import { ReportData } from '../types';
import { calculateCategoryStats, formatDate } from '../utils';
import { formatPrice } from '../../utils';

export function generateCategoryReport(doc: jsPDF, data: ReportData & { allTime?: boolean }) {
  if (!data.category) return doc;

  const filteredStandards = data.allTime 
    ? data.standards.filter(standard => standard.category === data.category)
    : data.standards.filter(standard => standard.category === data.category);

  const categoryStats = calculateCategoryStats(filteredStandards);

  // Category-specific statistics
  doc.setFontSize(14);
  doc.text('Category Statistics', 14, 70);
  doc.setFontSize(10);

  const categoryStatsData = [
    ['Total Standards', categoryStats.total.toString()],
    ['Mandatory Standards', categoryStats.mandatory.toString()],
    ['Optional Standards', categoryStats.optional.toString()],
    ['Average Price', formatPrice(categoryStats.averagePrice)],
    categoryStats.newest && ['Latest Standard', `${categoryStats.newest.title} (${formatDate(categoryStats.newest.releaseDate)})`],
  ].filter(Boolean);

  (doc as any).autoTable({
    startY: 75,
    head: [['Metric', 'Value']],
    body: categoryStatsData,
    theme: 'grid',
    headStyles: { fillColor: [0, 51, 102] },
  });

  // Standards list
  if (filteredStandards.length > 0) {
    doc.setFontSize(14);
    doc.text('Standards in Category', 14, (doc as any).lastAutoTable.finalY + 20);

    const standardsData = filteredStandards.map(s => [
      s.number,
      s.title,
      formatPrice(s.price),
      s.complianceType,
      formatDate(s.releaseDate),
    ]);

    (doc as any).autoTable({
      startY: (doc as any).lastAutoTable.finalY + 25,
      head: [['Number', 'Title', 'Price', 'Type', 'Release Date']],
      body: standardsData,
      theme: 'grid',
      headStyles: { fillColor: [0, 51, 102] },
    });
  }

  return doc;
}