import { jsPDF } from 'jspdf';
import { ReportData } from '../types';
import { formatDate } from '../utils';

export function addHeader(doc: jsPDF, data: ReportData & { allTime?: boolean }, reportType: string) {
  const pageWidth = doc.internal.pageSize.width;
  const today = new Date();

  doc.setFontSize(20);
  doc.text('SSMO Standards Report', pageWidth / 2, 20, { align: 'center' });
  doc.setFontSize(12);
  doc.text(`Report Type: ${reportType}${data.category ? ` - ${data.category}` : ''}`, pageWidth / 2, 30, { align: 'center' });
  
  if (!data.allTime) {
    doc.text(`Period: ${formatDate(data.period.startDate)} - ${formatDate(data.period.endDate)}`, pageWidth / 2, 40, { align: 'center' });
  } else {
    doc.text('Period: All Time', pageWidth / 2, 40, { align: 'center' });
  }
  
  doc.text(`Generated on: ${formatDate(today)}`, pageWidth / 2, 50, { align: 'center' });
}

export function addFooter(doc: jsPDF) {
  const pageWidth = doc.internal.pageSize.width;
  const pageCount = doc.internal.getNumberOfPages();
  
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.text(
      `Page ${i} of ${pageCount}`,
      pageWidth / 2,
      doc.internal.pageSize.height - 10,
      { align: 'center' }
    );
  }
}