import { Standard, Category, User } from '../../types';

export interface ReportPeriod {
  startDate: string;
  endDate: string;
}

export interface ReportStats {
  totalStandards: number;
  mandatoryStandards: number;
  categoriesCount: number;
  averagePrice: number;
}

export interface CustomerPurchase {
  id: string;
  userId: string;
  standardId: string;
  purchaseDate: string;
  price: number;
}

export interface ReportData {
  standards: Standard[];
  categories: Category[];
  stats: ReportStats;
  period: ReportPeriod;
  category?: string;
  customerName?: string;
  purchases?: CustomerPurchase[];
}

export type ReportType = 'summary' | 'detailed' | 'sales' | 'category' | 'customer';