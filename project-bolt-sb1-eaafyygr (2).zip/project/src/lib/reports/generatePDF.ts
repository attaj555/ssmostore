import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { ReportData, ReportType } from './types';
import { generateSummaryReport } from './generators/summaryReport';
import { generateCategoryReport } from './generators/categoryReport';
import { generateCustomerReport } from './generators/customerReport';
import { addHeader, addFooter } from './generators/common';

export function generatePDF(data: ReportData & { allTime?: boolean }, reportType: ReportType) {
  const doc = new jsPDF();

  // Add header
  addHeader(doc, data, reportType);

  // Generate report content based on type
  switch (reportType) {
    case 'category':
      generateCategoryReport(doc, data);
      break;
    case 'customer':
      generateCustomerReport(doc, data);
      break;
    case 'summary':
    default:
      generateSummaryReport(doc, data);
  }

  // Add footer
  addFooter(doc);

  return doc;
}