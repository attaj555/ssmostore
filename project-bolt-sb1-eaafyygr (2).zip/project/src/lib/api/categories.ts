import { Category } from '../../types';

export async function getCategories() {
  // In a real app, this would be an API call
  return Promise.resolve([]);
}

export async function createCategory(category: Omit<Category, 'id'>) {
  // In a real app, this would be an API call
  return Promise.resolve({ id: '1', ...category });
}

export async function updateCategory(id: string, category: Partial<Category>) {
  // In a real app, this would be an API call
  return Promise.resolve({ id, ...category });
}

export async function deleteCategory(id: string) {
  // In a real app, this would be an API call
  return Promise.resolve(true);
}