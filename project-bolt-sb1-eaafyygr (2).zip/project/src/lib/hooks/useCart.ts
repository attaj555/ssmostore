import { useStore } from '../../store/useStore';
import { Standard } from '../../types';

export function useCart() {
  const { cart, standards, addToCart, removeFromCart, updateCartItemQuantity, clearCart } = useStore();

  const cartItems = cart.map((item) => ({
    ...item,
    standard: standards.find((s) => s.id === item.standardId)!,
  }));

  const total = cartItems.reduce(
    (sum, item) => sum + item.standard.price * item.quantity,
    0
  );

  return {
    items: cartItems,
    total,
    addItem: addToCart,
    removeItem: removeFromCart,
    updateQuantity: updateCartItemQuantity,
    clear: clearCart,
  };
}