import { useStore } from '../../store/useStore';
import { useNavigate } from 'react-router-dom';

export function useAuth() {
  const { user, setUser } = useStore();
  const navigate = useNavigate();

  const login = async (email: string, password: string) => {
    // In a real app, this would validate credentials with an API
    const success = email === 'attaj555@gmail.com' && password === '123';
    if (success) {
      setUser({
        id: 'admin1',
        name: 'Admin User',
        email,
        role: 'admin',
      });
      navigate('/admin');
    }
    return success;
  };

  const logout = () => {
    setUser(null);
    navigate('/login');
  };

  return {
    user,
    login,
    logout,
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
  };
}