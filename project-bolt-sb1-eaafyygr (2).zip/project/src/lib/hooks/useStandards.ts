import { useStore } from '../../store/useStore';
import { Standard } from '../../types';

export function useStandards() {
  const { standards, addStandard, updateStandard, deleteStandard } = useStore();

  const filterStandards = (filters: {
    search?: string;
    category?: string;
    complianceType?: string;
  }) => {
    return standards.filter((standard: Standard) => {
      const matchesSearch = !filters.search || 
        standard.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        standard.number.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesCategory = !filters.category || 
        standard.category === filters.category;
      
      const matchesCompliance = !filters.complianceType || 
        standard.complianceType === filters.complianceType;

      return matchesSearch && matchesCategory && matchesCompliance;
    });
  };

  return {
    standards,
    addStandard,
    updateStandard,
    deleteStandard,
    filterStandards,
  };
}