import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../store/useStore';
import { Button } from '../../../components/ui/Button';
import { StandardsList } from '../components/StandardsList';
import { CategoryManagement } from '../components/CategoryManagement';
import { AdminManagement } from '../components/AdminManagement';
import { AdminPasswordManagement } from '../components/AdminPasswordManagement';
import { BankAccountManagement } from '../components/BankAccountManagement';
import { ReportsSection } from '../components/ReportsSection';
import { LayoutGrid, ListFilter, PieChart, Users, Lock, Building2 } from 'lucide-react';

type TabType = 'dashboard' | 'standards' | 'categories' | 'admins' | 'password' | 'bank-accounts';

export function AdminDashboard() {
  const { user } = useStore();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  // Redirect non-admin users
  React.useEffect(() => {
    if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
      navigate('/login');
    }
  }, [user, navigate]);

  if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">
          {user.role === 'super_admin' ? 'Super Admin Dashboard' : 'Admin Dashboard'}
        </h1>
        <div className="flex space-x-4">
          <Button
            variant={activeTab === 'dashboard' ? 'primary' : 'outline'}
            onClick={() => setActiveTab('dashboard')}
          >
            <LayoutGrid className="h-4 w-4 mr-2" />
            Overview
          </Button>
          <Button
            variant={activeTab === 'standards' ? 'primary' : 'outline'}
            onClick={() => setActiveTab('standards')}
          >
            <ListFilter className="h-4 w-4 mr-2" />
            Standards
          </Button>
          <Button
            variant={activeTab === 'categories' ? 'primary' : 'outline'}
            onClick={() => setActiveTab('categories')}
          >
            <PieChart className="h-4 w-4 mr-2" />
            Categories
          </Button>
          {user.role === 'super_admin' && (
            <>
              <Button
                variant={activeTab === 'admins' ? 'primary' : 'outline'}
                onClick={() => setActiveTab('admins')}
              >
                <Users className="h-4 w-4 mr-2" />
                Admins
              </Button>
              <Button
                variant={activeTab === 'bank-accounts' ? 'primary' : 'outline'}
                onClick={() => setActiveTab('bank-accounts')}
              >
                <Building2 className="h-4 w-4 mr-2" />
                Bank Accounts
              </Button>
            </>
          )}
          <Button
            variant={activeTab === 'password' ? 'primary' : 'outline'}
            onClick={() => setActiveTab('password')}
          >
            <Lock className="h-4 w-4 mr-2" />
            Password
          </Button>
        </div>
      </div>

      {activeTab === 'dashboard' && <ReportsSection />}
      {activeTab === 'standards' && <StandardsList />}
      {activeTab === 'categories' && <CategoryManagement />}
      {activeTab === 'admins' && user.role === 'super_admin' && <AdminManagement />}
      {activeTab === 'bank-accounts' && user.role === 'super_admin' && <BankAccountManagement />}
      {activeTab === 'password' && <AdminPasswordManagement />}
    </div>
  );
}