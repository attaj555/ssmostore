import React, { useState } from 'react';
import { Button } from '../../../components/ui/Button';
import { FileText, X } from 'lucide-react';
import { Input } from '../../../components/ui/Input';
import { useStore } from '../../../store/useStore';

interface ReportDialogProps {
  onGenerate: (
    type: string, 
    period: { startDate: string; endDate: string } | null, 
    category?: string,
    customerName?: string
  ) => void;
  onClose: () => void;
}

export function ReportDialog({ onGenerate, onClose }: ReportDialogProps) {
  const { categories } = useStore();
  const [reportType, setReportType] = useState('summary');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [usePeriod, setUsePeriod] = useState(true);
  const [period, setPeriod] = useState({
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
  });

  const handleGenerate = () => {
    if (reportType === 'customer' && !customerName.trim()) {
      alert('Please enter a customer name');
      return;
    }

    if (usePeriod) {
      if (!period.startDate || !period.endDate) {
        alert('Please select both start and end dates');
        return;
      }
      if (new Date(period.startDate) > new Date(period.endDate)) {
        alert('Start date cannot be after end date');
        return;
      }
      onGenerate(reportType, period, selectedCategory, customerName);
    } else {
      onGenerate(reportType, null, selectedCategory, customerName);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Generate Report</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Report Type
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            >
              <option value="summary">Summary Report</option>
              <option value="detailed">Detailed Report</option>
              <option value="sales">Sales Report</option>
              <option value="category">Category Report</option>
              <option value="customer">Customer Report</option>
            </select>
          </div>

          {reportType === 'category' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Category
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                required={reportType === 'category'}
              >
                <option value="">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.slug}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {reportType === 'customer' && (
            <Input
              label="Customer Name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Enter customer name"
              required
            />
          )}

          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="usePeriod"
                checked={usePeriod}
                onChange={(e) => setUsePeriod(e.target.checked)}
                className="rounded border-gray-300 text-primary focus:ring-primary"
              />
              <label htmlFor="usePeriod" className="text-sm font-medium text-gray-700">
                Filter by Period
              </label>
            </div>

            {usePeriod && (
              <div className="grid grid-cols-2 gap-4 mt-2">
                <Input
                  type="date"
                  label="Start Date"
                  value={period.startDate}
                  onChange={(e) => setPeriod({ ...period, startDate: e.target.value })}
                  required
                />
                <Input
                  type="date"
                  label="End Date"
                  value={period.endDate}
                  onChange={(e) => setPeriod({ ...period, endDate: e.target.value })}
                  required
                />
              </div>
            )}
          </div>

          <div className="text-sm text-gray-500">
            {reportType === 'summary' && (
              <p>Includes basic statistics and category distribution{!usePeriod && ' for all time'}.</p>
            )}
            {reportType === 'detailed' && (
              <p>Includes detailed standards information and comprehensive analytics{!usePeriod && ' for all time'}.</p>
            )}
            {reportType === 'sales' && (
              <p>Includes sales data, revenue analysis, and popular standards{!usePeriod && ' for all time'}.</p>
            )}
            {reportType === 'category' && (
              <p>Detailed analysis of standards within the selected category{!usePeriod && ' for all time'}.</p>
            )}
            {reportType === 'customer' && (
              <p>Purchase history and analytics for the specified customer{!usePeriod && ' for all time'}.</p>
            )}
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleGenerate}>
              <FileText className="h-4 w-4 mr-2" />
              Generate PDF
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}