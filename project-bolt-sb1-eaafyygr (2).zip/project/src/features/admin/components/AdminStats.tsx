import React from 'react';
import { useStore } from '../../../store/useStore';

export function AdminStats() {
  const { standards } = useStore();

  const stats = [
    { label: 'Total Standards', value: standards.length },
    { label: 'Active Users', value: '120' },
    { label: 'Total Sales', value: '$1,234' },
    { label: 'This Month', value: '$456' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-white p-6 rounded-lg shadow">
          <p className="text-sm text-gray-500">{stat.label}</p>
          <p className="text-2xl font-bold">{stat.value}</p>
        </div>
      ))}
    </div>
  );
}