import React, { useState } from 'react';
import { useStore } from '../../../store/useStore';
import { formatPrice } from '../../../lib/utils';
import { generatePDF } from '../../../lib/reports/generatePDF';
import { ReportDialog } from './ReportDialog';
import {
  BarChart,
  LineChart,
  PieChart,
  Download,
  TrendingUp,
  DollarSign,
  FileText,
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';

export function ReportsSection() {
  const { standards, categories } = useStore();
  const [showReportDialog, setShowReportDialog] = useState(false);

  const stats = {
    totalStandards: standards.length,
    mandatoryStandards: standards.filter((s) => s.complianceType === 'mandatory')
      .length,
    categoriesCount: categories.length,
    averagePrice: standards.reduce((acc, s) => acc + s.price, 0) / standards.length,
  };

  // Sample purchase data - in a real app, this would come from your backend
  const samplePurchases = [
    {
      id: '1',
      userId: 'user1',
      standardId: '1',
      purchaseDate: '2024-03-01',
      price: 49.99,
    },
    {
      id: '2',
      userId: 'user1',
      standardId: '2',
      purchaseDate: '2024-03-15',
      price: 59.99,
    },
  ];

  const handleGenerateReport = (
    reportType: string, 
    period: { startDate: string; endDate: string } | null,
    category?: string,
    customerName?: string
  ) => {
    const doc = generatePDF({ 
      standards, 
      categories, 
      stats,
      period: period || {
        startDate: '1970-01-01',
        endDate: new Date().toISOString().split('T')[0],
      },
      category,
      customerName,
      purchases: samplePurchases,
      allTime: !period,
    }, reportType);

    const fileName = `ssmo-standards-report-${reportType}${category ? `-${category}` : ''}${
      customerName ? `-${customerName}` : ''
    }${period ? `-${period.startDate}-to-${period.endDate}` : '-all-time'}.pdf`;
    
    doc.save(fileName);
    setShowReportDialog(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Reports & Analytics</h2>
        <Button onClick={() => setShowReportDialog(true)}>
          <FileText className="h-4 w-4 mr-2" />
          Generate Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Standards</p>
              <p className="text-2xl font-bold">{standards.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-full">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Categories</p>
              <p className="text-2xl font-bold">{categories.length}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-full">
              <PieChart className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Mandatory Standards</p>
              <p className="text-2xl font-bold">{stats.mandatoryStandards}</p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-full">
              <TrendingUp className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Average Price</p>
              <p className="text-2xl font-bold">{formatPrice(stats.averagePrice)}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-full">
              <DollarSign className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {showReportDialog && (
        <ReportDialog
          onGenerate={handleGenerateReport}
          onClose={() => setShowReportDialog(false)}
        />
      )}
    </div>
  );
}