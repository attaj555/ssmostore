import React, { useState } from 'react';
import { useStore } from '../../../store/useStore';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { Category } from '../../../types';
import { Plus, Pencil, Trash2, AlertTriangle } from 'lucide-react';

export function CategoryManagement() {
  const { categories, addCategory, updateCategory, deleteCategory } = useStore();
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategory, setNewCategory] = useState({
    name: '',
    slug: '',
    description: '',
  });
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [showDeleteWarning, setShowDeleteWarning] = useState<string | null>(null);

  const handleSubmitNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategory.name.trim()) {
      alert('Category title is mandatory');
      return;
    }
    addCategory({
      ...newCategory,
      slug: newCategory.name.toLowerCase().replace(/\s+/g, '-'),
    });
    setNewCategory({ name: '', slug: '', description: '' });
    setIsAddingNew(false);
  };

  const handleSubmitEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCategory) {
      if (!editingCategory.name.trim()) {
        alert('Category title is mandatory');
        return;
      }
      updateCategory(editingCategory.id, editingCategory);
      setEditingCategory(null);
    }
  };

  const handleDelete = (id: string) => {
    deleteCategory(id);
    setShowDeleteWarning(null);
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b flex justify-between items-center">
        <h2 className="text-xl font-semibold">Category Management</h2>
        <Button onClick={() => setIsAddingNew(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Category
        </Button>
      </div>
      
      {isAddingNew && (
        <div className="p-6 border-b bg-gray-50">
          <form onSubmit={handleSubmitNew} className="space-y-4">
            <Input
              label="Category Name"
              value={newCategory.name}
              onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
              required
              error={!newCategory.name.trim() ? 'Category title is mandatory' : ''}
            />
            <Input
              label="Description"
              value={newCategory.description}
              onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
            />
            <div className="flex space-x-2">
              <Button type="submit">Add Category</Button>
              <Button type="button" variant="outline" onClick={() => setIsAddingNew(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      <div className="p-6">
        <div className="space-y-4">
          {categories.map((category) => (
            <div key={category.id} className="border rounded-lg p-4">
              {showDeleteWarning === category.id ? (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-red-600 mb-4">
                    <AlertTriangle className="h-5 w-5" />
                    <span className="font-medium">Delete Category?</span>
                  </div>
                  <p className="text-sm text-red-600 mb-4">
                    Are you sure you want to delete this category? This action cannot be undone.
                  </p>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      className="bg-red-600 text-white hover:bg-red-700"
                      onClick={() => handleDelete(category.id)}
                    >
                      Delete
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowDeleteWarning(null)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : editingCategory?.id === category.id ? (
                <form onSubmit={handleSubmitEdit} className="space-y-4">
                  <Input
                    label="Name"
                    value={editingCategory.name}
                    onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                    error={!editingCategory.name.trim() ? 'Category title is mandatory' : ''}
                  />
                  <Input
                    label="Description"
                    value={editingCategory.description}
                    onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  />
                  <div className="flex space-x-2">
                    <Button type="submit">Save Changes</Button>
                    <Button type="button" variant="outline" onClick={() => setEditingCategory(null)}>
                      Cancel
                    </Button>
                  </div>
                </form>
              ) : (
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{category.name}</h4>
                    <p className="text-sm text-gray-500">{category.description}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingCategory(category)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowDeleteWarning(category.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}