import React, { useState } from 'react';
import { useStore } from '../../../store/useStore';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog';
import { Building2, Edit2, Save, Trash2, AlertTriangle, Plus } from 'lucide-react';
import { Bank, BankAccount } from '../../../lib/payment/types';
import { FileUpload } from '../../../components/ui/FileUpload';

export function BankAccountManagement() {
  const { user, banks = [], addBank, updateBankAccount, deleteBankAccount } = useStore();
  const [editingBank, setEditingBank] = useState<string | null>(null);
  const [bankToDelete, setBankToDelete] = useState<Bank | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [formData, setFormData] = useState<Partial<Bank & BankAccount>>({});
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (user?.role !== 'super_admin') return null;

  const handleAddBank = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.name || !formData.code || !formData.accountNumber || !formData.branch) {
      setError('All fields are required');
      return;
    }

    if (!logoFile && !formData.logo) {
      setError('Bank logo is required');
      return;
    }

    try {
      let logoUrl = formData.logo;
      if (logoFile) {
        const reader = new FileReader();
        await new Promise((resolve, reject) => {
          reader.onload = resolve;
          reader.onerror = reject;
          reader.readAsDataURL(logoFile);
        });
        logoUrl = reader.result as string;
      }

      await addBank({
        name: formData.name,
        code: formData.code,
        logo: logoUrl!,
        accounts: [{
          accountNumber: formData.accountNumber,
          accountName: formData.accountName || formData.name,
          branch: formData.branch,
          isActive: true,
          lastUpdated: new Date().toISOString(),
          updatedBy: user.id,
        }],
      });

      setSuccess('Bank added successfully');
      setIsAddingNew(false);
      setFormData({});
      setLogoFile(null);
    } catch (err) {
      setError('Failed to add bank');
    }
  };

  const handleUpdateBank = async (bankId: string) => {
    try {
      await updateBankAccount(bankId, {
        accountNumber: formData.accountNumber!,
        branch: formData.branch!,
        lastUpdated: new Date().toISOString(),
        updatedBy: user.id,
      });
      setSuccess('Bank account updated successfully');
      setEditingBank(null);
      setFormData({});
    } catch (err) {
      setError('Failed to update bank account');
    }
  };

  const handleDelete = async () => {
    if (!bankToDelete) return;

    try {
      await deleteBankAccount(bankToDelete.id);
      setSuccess('Bank account removed successfully');
      setBankToDelete(null);
    } catch (err) {
      setError('Failed to remove bank account');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Building2 className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">Bank Account Management</h2>
          </div>
          <Button onClick={() => setIsAddingNew(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Bank
          </Button>
        </div>
      </div>

      {(error || success) && (
        <div className={`p-4 ${error ? 'bg-red-50' : 'bg-green-50'}`}>
          <p className={`text-sm ${error ? 'text-red-600' : 'text-green-600'}`}>
            {error || success}
          </p>
        </div>
      )}

      {isAddingNew && (
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium mb-4">Add New Bank</h3>
          <form onSubmit={handleAddBank} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Bank Name"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
              <Input
                label="Bank Code"
                value={formData.code || ''}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bank Logo
              </label>
              <FileUpload
                onChange={setLogoFile}
                value={logoFile}
                accept="image/*,application/pdf"
                maxSize={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Account Number"
                value={formData.accountNumber || ''}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                required
              />
              <Input
                label="Branch"
                value={formData.branch || ''}
                onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                required
              />
            </div>

            <div className="flex space-x-2">
              <Button type="submit">Add Bank</Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsAddingNew(false);
                  setFormData({});
                  setLogoFile(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      <div className="p-6">
        <div className="space-y-6">
          {banks.map((bank) => (
            <div key={bank.id} className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img
                    src={bank.logo}
                    alt={bank.name}
                    className="h-12 w-auto"
                  />
                  <div>
                    <h4 className="font-medium">{bank.name}</h4>
                    <p className="text-sm text-gray-500">Code: {bank.code}</p>
                    {editingBank === bank.id ? (
                      <div className="mt-2 space-y-2">
                        <Input
                          label="Account Number"
                          value={formData.accountNumber || bank.accounts[0]?.accountNumber}
                          onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                          required
                        />
                        <Input
                          label="Branch"
                          value={formData.branch || bank.accounts[0]?.branch}
                          onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                          required
                        />
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            onClick={() => handleUpdateBank(bank.id)}
                          >
                            <Save className="h-4 w-4 mr-1" />
                            Save
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingBank(null);
                              setFormData({});
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-2">
                        <p className="text-sm">
                          Account: {bank.accounts[0]?.accountNumber}
                        </p>
                        <p className="text-sm">
                          Branch: {bank.accounts[0]?.branch}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2">
                  {editingBank !== bank.id && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingBank(bank.id)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setBankToDelete(bank)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}

          {banks.length === 0 && !isAddingNew && (
            <div className="text-center py-6 text-gray-500">
              No banks added yet
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        isOpen={!!bankToDelete}
        title="Remove Bank"
        message={`Are you sure you want to remove ${bankToDelete?.name}? This action cannot be undone.`}
        confirmLabel="Remove"
        onConfirm={handleDelete}
        onCancel={() => setBankToDelete(null)}
      />
    </div>
  );
}