import React, { useState } from 'react';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { FileUpload } from '../../../components/ui/FileUpload';
import { Standard } from '../../../types';
import { useStore } from '../../../store/useStore';
import { uploadStandardPDF } from '../../../lib/storage/fileStorage';

interface StandardFormProps {
  standard?: Standard;
  onSubmit: (data: Partial<Standard>) => void;
  onCancel?: () => void;
}

export function StandardForm({ standard, onSubmit, onCancel }: StandardFormProps) {
  const { categories } = useStore();
  const [formData, setFormData] = useState<Partial<Standard>>({
    title: standard?.title || '',
    number: standard?.number || '',
    category: standard?.category || '',
    description: standard?.description || '',
    price: standard?.price || 0,
    complianceType: standard?.complianceType || 'optional',
    isLatest: standard?.isLatest ?? true,
    releaseDate: standard?.releaseDate || new Date().toISOString().split('T')[0],
    pdfUrl: standard?.pdfUrl || '',
  });
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploadError('');
    setIsSubmitting(true);

    try {
      let pdfUrl = formData.pdfUrl;
      
      // Upload new PDF if provided
      if (pdfFile) {
        pdfUrl = await uploadStandardPDF(pdfFile);
      }

      // Submit form with PDF URL
      await onSubmit({
        ...formData,
        pdfUrl,
      });
    } catch (error) {
      setUploadError('Failed to upload PDF. Please try again.');
      console.error('Upload error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Standard Number"
          value={formData.number}
          onChange={(e) => setFormData({ ...formData, number: e.target.value })}
          required
        />
        <Input
          label="Title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            required
          >
            <option value="">Select Category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.slug}>
                {cat.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Compliance Type
          </label>
          <select
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            value={formData.complianceType}
            onChange={(e) => setFormData({ ...formData, complianceType: e.target.value as 'mandatory' | 'optional' })}
            required
          >
            <option value="mandatory">Mandatory</option>
            <option value="optional">Optional</option>
          </select>
        </div>
      </div>

      <Input
        label="Description"
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
        required
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Price"
          type="number"
          min="0"
          step="0.01"
          value={formData.price?.toString()}
          onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
          required
        />
        <Input
          label="Release Date"
          type="date"
          value={formData.releaseDate?.split('T')[0]}
          onChange={(e) => setFormData({ ...formData, releaseDate: e.target.value })}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          PDF File {!standard?.pdfUrl && '*'}
        </label>
        <FileUpload
          onChange={setPdfFile}
          value={pdfFile}
          currentFileName={standard?.pdfUrl ? `Current PDF File` : undefined}
          accept=".pdf"
          maxSize={20}
        />
        {uploadError && (
          <p className="mt-1 text-sm text-red-600">{uploadError}</p>
        )}
      </div>

      <div className="flex justify-end space-x-2">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : standard ? 'Update Standard' : 'Add Standard'}
        </Button>
      </div>
    </form>
  );
}