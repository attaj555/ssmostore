import React, { useState } from 'react';
import { useStore } from '../../../store/useStore';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { User } from '../../../types';
import { Plus, Trash2, AlertTriangle, Info } from 'lucide-react';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog';

export function AdminManagement() {
  const { user: currentUser, admins, addAdmin, removeAdmin } = useStore();
  const [newAdmin, setNewAdmin] = useState({ email: '', name: '' });
  const [adminToDelete, setAdminToDelete] = useState<User | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (currentUser?.role !== 'super_admin') {
    return null;
  }

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!newAdmin.email || !newAdmin.name) {
      setError('Please fill in all fields');
      return;
    }

    try {
      await addAdmin({
        email: newAdmin.email,
        name: newAdmin.name,
      });
      setSuccess(`Activation email sent to ${newAdmin.email}`);
      setNewAdmin({ email: '', name: '' });
      setIsAddingNew(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add admin');
    }
  };

  const handleDeleteAdmin = async () => {
    if (adminToDelete) {
      try {
        await removeAdmin(adminToDelete.id);
        setSuccess(`${adminToDelete.name} has been removed from admin role`);
        setAdminToDelete(null);
      } catch (err) {
        setError('Failed to remove admin');
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Admin Management</h2>
          <Button onClick={() => setIsAddingNew(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Admin
          </Button>
        </div>
      </div>

      {(error || success) && (
        <div className={`p-4 ${error ? 'bg-red-50' : 'bg-green-50'}`}>
          <p className={`text-sm ${error ? 'text-red-600' : 'text-green-600'}`}>
            {error || success}
          </p>
        </div>
      )}

      {isAddingNew && (
        <div className="p-6 border-b">
          <form onSubmit={handleAddAdmin} className="space-y-4">
            <Input
              label="Name"
              value={newAdmin.name}
              onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
              required
            />
            <div className="space-y-1">
              <Input
                label="Email"
                type="email"
                value={newAdmin.email}
                onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                required
              />
              <div className="flex items-start space-x-2 text-sm text-gray-500">
                <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <p>Admin email must be a valid SSMO email address (@ssmo.gov.sd)</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button type="submit">Add Admin</Button>
              <Button type="button" variant="outline" onClick={() => setIsAddingNew(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      <div className="p-6">
        <div className="space-y-4">
          {admins.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No admins added yet</p>
          ) : (
            admins.map((admin) => (
              <div key={admin.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{admin.name}</p>
                  <p className="text-sm text-gray-500">{admin.email}</p>
                  <p className="text-xs text-gray-400">Added on {new Date(admin.createdAt).toLocaleDateString()}</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAdminToDelete(admin)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>

      <ConfirmDialog
        isOpen={!!adminToDelete}
        title="Remove Admin"
        message={`Are you sure you want to remove ${adminToDelete?.name} from admin role? This action cannot be undone.`}
        confirmLabel="Remove"
        onConfirm={handleDeleteAdmin}
        onCancel={() => setAdminToDelete(null)}
      />
    </div>
  );
}