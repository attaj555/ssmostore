export interface BillingAddress {
  company?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
}

export interface CheckoutFormData {
  billingName: string;
  billingEmail: string;
  billingCompany?: string;
  billingAddress?: string;
  billingCity?: string;
  billingState?: string;
  billingZip?: string;
  billingCountry?: string;
  paymentMethod: string;
}