import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../store/useStore';
import { PaymentMethodSelector } from '../components/PaymentMethodSelector';
import { BankPaymentForm } from '../components/BankPaymentForm';
import { CardPaymentForm } from '../components/CardPaymentForm';
import { OrderSummary } from '../components/OrderSummary';
import { PaymentMethod, PaymentDetails } from '../../../lib/payment/types';
import { processPayment } from '../../../lib/payment/processor';

export function CheckoutPage() {
  const navigate = useNavigate();
  const { cart, standards, clearCart, user } = useStore();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Redirect if not logged in or cart is empty
  React.useEffect(() => {
    if (!user) {
      navigate('/login', { state: { returnTo: '/checkout' } });
    } else if (cart.length === 0) {
      navigate('/cart');
    }
  }, [user, cart.length, navigate]);

  const cartItems = cart.map((item) => ({
    ...item,
    standard: standards.find((s) => s.id === item.standardId)!,
  }));

  const total = cartItems.reduce(
    (sum, item) => sum + item.standard.price * item.quantity,
    0
  );

  const handlePayment = async (details: PaymentDetails) => {
    setError('');
    setIsProcessing(true);
    
    try {
      const result = await processPayment(details);
      if (result.success) {
        clearCart();
        navigate('/checkout/success', { 
          state: { 
            orderId: result.orderId,
            standards: cartItems.map(item => item.standard)
          }
        });
      } else {
        setError(result.error || 'Payment failed');
      }
    } catch (err) {
      setError('Failed to process payment. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  if (!user || cart.length === 0) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Checkout</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          <PaymentMethodSelector
            selectedMethod={paymentMethod}
            onSelect={setPaymentMethod}
          />

          <div className="bg-white rounded-lg shadow-sm p-6">
            {paymentMethod === 'bank_transfer' && (
              <BankPaymentForm
                amount={total}
                onSubmit={handlePayment}
              />
            )}
            {paymentMethod === 'local_card' && (
              <CardPaymentForm
                amount={total}
                type="local_card"
                onSubmit={handlePayment}
              />
            )}
            {paymentMethod === 'international_card' && (
              <CardPaymentForm
                amount={total}
                type="international_card"
                onSubmit={handlePayment}
              />
            )}
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}
          {isProcessing && (
            <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
              <p className="text-sm text-blue-600">
                Processing payment... Please wait.
              </p>
            </div>
          )}
        </div>

        <div className="lg:sticky lg:top-8">
          <OrderSummary items={cartItems} />
        </div>
      </div>
    </div>
  );
}