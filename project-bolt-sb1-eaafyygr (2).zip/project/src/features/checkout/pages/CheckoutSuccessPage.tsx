import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckCircle, Download, FileText } from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Standard } from '../../../types';
import { formatPrice } from '../../../lib/utils';
import { downloadStandardPDF } from '../../../lib/storage/fileStorage';
import { addWatermark } from '../../../lib/pdf/watermark';
import { useStore } from '../../../store/useStore';

interface LocationState {
  orderId: string;
  standards: Standard[];
}

export function CheckoutSuccessPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useStore();
  const state = location.state as LocationState;

  useEffect(() => {
    if (!state?.orderId || !state?.standards) {
      navigate('/standards');
    }
  }, [state, navigate]);

  if (!state?.orderId || !state?.standards || !user) {
    return null;
  }

  const handleDownload = async (standard: Standard) => {
    try {
      // In a real app, fetch the PDF file from the server
      const response = await fetch(standard.pdfUrl);
      const pdfBlob = await response.blob();
      const pdfFile = new File([pdfBlob], `${standard.number}.pdf`, { type: 'application/pdf' });
      
      // Add watermark with user's name
      const watermarkedPdf = await addWatermark(pdfFile, user.name);
      
      // Trigger download
      const downloadUrl = URL.createObjectURL(watermarkedPdf);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `${standard.number}-${standard.title}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download the standard. Please try again.');
    }
  };

  const total = state.standards.reduce((sum, standard) => sum + standard.price, 0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Payment Successful!
          </h1>
          <p className="text-gray-600">
            Order #{state.orderId}
          </p>
        </div>

        <div className="border-t border-b py-4 mb-6">
          <h2 className="text-lg font-semibold mb-4">Your Standards</h2>
          <div className="space-y-4">
            {state.standards.map((standard) => (
              <div key={standard.id} className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{standard.title}</h3>
                  <p className="text-sm text-gray-500">Standard No: {standard.number}</p>
                  <p className="text-sm font-medium">{formatPrice(standard.price)}</p>
                </div>
                <Button onClick={() => handleDownload(standard)}>
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-between items-center text-lg font-semibold mb-6">
          <span>Total</span>
          <span>{formatPrice(total)}</span>
        </div>

        <div className="text-center space-y-4">
          <Button onClick={() => navigate('/standards')} variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Browse More Standards
          </Button>
        </div>
      </div>
    </div>
  );
}