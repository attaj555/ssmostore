import React, { useState } from 'react';
import { PaymentMethodSelector } from './PaymentMethodSelector';
import { BillingAddressForm } from './BillingAddressForm';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { PaymentMethod } from '../../../types/enums';

interface CheckoutFormProps {
  onSubmit: (data: any) => void;
}

export function CheckoutForm({ onSubmit }: CheckoutFormProps) {
  const [formData, setFormData] = useState({
    // Required Information
    billingName: '',
    billingEmail: '',
    // Optional Billing Address
    billingCompany: '',
    billingAddress: '',
    billingCity: '',
    billingState: '',
    billingZip: '',
    billingCountry: '',
    // Payment Information
    paymentMethod: PaymentMethod.CREDIT_CARD,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleBillingAddressChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [`billing${field.charAt(0).toUpperCase()}${field.slice(1)}`]: value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow">
      <div>
        <h2 className="text-xl font-semibold mb-4">Required Information</h2>
        <div className="space-y-4">
          <Input
            label="Full Name"
            value={formData.billingName}
            onChange={(e) => setFormData({ ...formData, billingName: e.target.value })}
            required
          />
          <Input
            label="Email"
            type="email"
            value={formData.billingEmail}
            onChange={(e) => setFormData({ ...formData, billingEmail: e.target.value })}
            required
          />
        </div>
      </div>

      <BillingAddressForm
        values={{
          company: formData.billingCompany,
          address: formData.billingAddress,
          city: formData.billingCity,
          state: formData.billingState,
          zipCode: formData.billingZip,
          country: formData.billingCountry,
        }}
        onChange={handleBillingAddressChange}
      />

      <div>
        <h2 className="text-xl font-semibold mb-4">Payment Method</h2>
        <PaymentMethodSelector
          selectedMethod={formData.paymentMethod}
          onSelect={(method) => setFormData({ ...formData, paymentMethod: method })}
        />
      </div>

      <Button type="submit" className="w-full">
        Complete Purchase
      </Button>
    </form>
  );
}