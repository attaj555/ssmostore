import React from 'react';
import { Input } from '../../../components/ui/Input';

interface BillingAddressFormProps {
  values: {
    company?: string;
    address?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
  onChange: (field: string, value: string) => void;
}

export function BillingAddressForm({ values, onChange }: BillingAddressFormProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-700">Billing Address (Optional)</h3>
      <p className="text-sm text-gray-500 mb-4">
        Fill in these details if you need them on your invoice.
      </p>
      
      <Input
        label="Company (Optional)"
        value={values.company || ''}
        onChange={(e) => onChange('company', e.target.value)}
      />
      
      <Input
        label="Street Address (Optional)"
        value={values.address || ''}
        onChange={(e) => onChange('address', e.target.value)}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="City (Optional)"
          value={values.city || ''}
          onChange={(e) => onChange('city', e.target.value)}
        />
        <Input
          label="State/Province (Optional)"
          value={values.state || ''}
          onChange={(e) => onChange('state', e.target.value)}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="ZIP/Postal Code (Optional)"
          value={values.zipCode || ''}
          onChange={(e) => onChange('zipCode', e.target.value)}
        />
        <Input
          label="Country (Optional)"
          value={values.country || ''}
          onChange={(e) => onChange('country', e.target.value)}
        />
      </div>
    </div>
  );
}