import React from 'react';
import { FileText } from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { downloadStandardPDF } from '../../../lib/storage/fileStorage';
import { addWatermark } from '../../../lib/pdf/watermark';
import { Standard } from '../../../types';

interface DownloadSectionProps {
  standards: Standard[];
  buyerName: string;
}

export function DownloadSection({ standards, buyerName }: DownloadSectionProps) {
  const handleDownload = async (standard: Standard) => {
    try {
      // In a real app, fetch the PDF file from the server
      const response = await fetch(standard.pdfUrl);
      const pdfBlob = await response.blob();
      const pdfFile = new File([pdfBlob], `${standard.number}.pdf`, { type: 'application/pdf' });
      
      // Add watermark
      const watermarkedPdf = await addWatermark(pdfFile, buyerName);
      
      // Trigger download
      const downloadUrl = URL.createObjectURL(watermarkedPdf);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `${standard.number}-${standard.title}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download the standard. Please try again.');
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Download Your Standards</h3>
      {standards.map((standard) => (
        <div key={standard.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div>
            <p className="font-medium">{standard.title}</p>
            <p className="text-sm text-gray-500">Standard No: {standard.number}</p>
          </div>
          <Button onClick={() => handleDownload(standard)}>
            <FileText className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      ))}
    </div>
  );
}