import React, { useState } from 'react';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { BANK_TRANSFER_PROVIDERS } from '../../../lib/payment/providers';
import { PaymentDetails } from '../../../lib/payment/types';
import { formatPrice } from '../../../lib/utils';
import { Info } from 'lucide-react';
import { useStore } from '../../../store/useStore';

interface BankPaymentFormProps {
  amount: number;
  onSubmit: (details: PaymentDetails) => void;
}

export function BankPaymentForm({ amount, onSubmit }: BankPaymentFormProps) {
  const { user } = useStore();
  const [selectedBank, setSelectedBank] = useState('');
  const [formData, setFormData] = useState({
    accountNumber: '',
    referenceNumber: '',
    payerName: '',
    payerPhone: '',
    paymentDate: new Date().toISOString().split('T')[0],
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedBank) {
      setError('Please select a bank');
      return;
    }

    onSubmit({
      method: 'bank_transfer',
      amount,
      currency: 'SDG',
      bankId: selectedBank,
      ...formData,
    });
  };

  const selectedBankInfo = BANK_TRANSFER_PROVIDERS.find(b => b.id === selectedBank);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Total Amount</h3>
        <p className="text-2xl font-bold text-primary">{formatPrice(amount)}</p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select Bank
        </label>
        <select
          value={selectedBank}
          onChange={(e) => setSelectedBank(e.target.value)}
          className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          required
        >
          <option value="">Choose a bank</option>
          {BANK_TRANSFER_PROVIDERS.map((bank) => (
            <option key={bank.id} value={bank.id}>
              {bank.name}
            </option>
          ))}
        </select>
      </div>

      {selectedBankInfo && (
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <img
                src={selectedBankInfo.logo}
                alt={selectedBankInfo.name}
                className="h-12 w-auto"
              />
              <div>
                <h4 className="font-medium">{selectedBankInfo.name}</h4>
                <p className="text-sm text-gray-600">
                  Account: {selectedBankInfo.accountNumber}
                </p>
                <p className="text-sm text-gray-600">
                  Branch: {selectedBankInfo.branch}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-start space-x-2 text-sm text-blue-600 bg-blue-100 p-3 rounded">
            <Info className="h-5 w-5 flex-shrink-0" />
            <p>
              Please make the transfer to this account and then provide your transaction details below.
            </p>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <Input
          label="Your Account Number"
          value={formData.accountNumber}
          onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
          placeholder="Enter your bank account number"
          required
          pattern="\d{10,16}"
          title="Account number must be between 10-16 digits"
        />

        <Input
          label="Transaction Reference Number"
          value={formData.referenceNumber}
          onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
          placeholder="Enter the reference number from your transfer"
          required
          pattern="[A-Za-z0-9]{8,}"
          title="Reference number must be at least 8 alphanumeric characters"
        />

        <Input
          label="Your Name"
          value={formData.payerName}
          onChange={(e) => setFormData({ ...formData, payerName: e.target.value })}
          placeholder="Enter the name on your bank account"
          required
        />

        <Input
          label="Phone Number"
          value={formData.payerPhone}
          onChange={(e) => setFormData({ ...formData, payerPhone: e.target.value })}
          placeholder="+249XXXXXXXXX"
          pattern="(\+249|0)?[0-9]{9}"
          title="Enter a valid Sudanese phone number"
          required
        />

        <Input
          type="date"
          label="Payment Date"
          value={formData.paymentDate}
          onChange={(e) => setFormData({ ...formData, paymentDate: e.target.value })}
          max={new Date().toISOString().split('T')[0]}
          required
        />
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-md p-3">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <Button type="submit" className="w-full">
        Verify Payment
      </Button>
    </form>
  );
}