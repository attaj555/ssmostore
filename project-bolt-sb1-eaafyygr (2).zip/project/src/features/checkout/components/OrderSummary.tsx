import React from 'react';
import { formatPrice } from '../../../lib/utils';
import { CartItem, Standard } from '../../../types';

interface OrderSummaryProps {
  items: (CartItem & { standard: Standard })[];
}

export function OrderSummary({ items }: OrderSummaryProps) {
  const total = items.reduce(
    (sum, item) => sum + item.standard.price * item.quantity,
    0
  );

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.standardId} className="flex justify-between">
            <div>
              <p className="font-medium">{item.standard.title}</p>
              <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
            </div>
            <span>{formatPrice(item.standard.price * item.quantity)}</span>
          </div>
        ))}
        <div className="border-t pt-4">
          <div className="flex justify-between font-bold">
            <span>Total</span>
            <span>{formatPrice(total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}