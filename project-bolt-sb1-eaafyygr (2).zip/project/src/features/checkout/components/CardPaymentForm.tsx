import React, { useState, useEffect } from 'react';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { PaymentDetails } from '../../../lib/payment/types';
import { detectCardType, formatCardNumber, validateCardNumber, CARD_LOGOS, CardType } from '../../../lib/payment/cardDetection';
import { CreditCard, AlertCircle } from 'lucide-react';
import { formatPrice } from '../../../lib/utils';

interface CardPaymentFormProps {
  amount: number;
  type: 'local_card' | 'international_card';
  onSubmit: (details: PaymentDetails) => void;
}

export function CardPaymentForm({ amount, type, onSubmit }: CardPaymentFormProps) {
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardExpiry: '',
    cardCvc: '',
    cardHolderName: '',
  });
  const [cardType, setCardType] = useState<CardType>('unknown');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (formData.cardNumber) {
      const detected = detectCardType(formData.cardNumber.replace(/\s/g, ''));
      setCardType(detected);
    } else {
      setCardType('unknown');
    }
  }, [formData.cardNumber]);

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCardNumber(e.target.value);
    setFormData({ ...formData, cardNumber: formatted });
    setError('');
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D+/g, '');
    if (value.length > 4) return;
    
    if (value.length >= 2) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    
    setFormData({ ...formData, cardExpiry: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Basic validations
    if (!formData.cardNumber.trim()) {
      setError('Card number is required');
      return;
    }

    if (!formData.cardExpiry.trim()) {
      setError('Expiry date is required');
      return;
    }

    if (!formData.cardCvc.trim()) {
      setError('CVC is required');
      return;
    }

    if (!formData.cardHolderName.trim()) {
      setError('Cardholder name is required');
      return;
    }

    // Validate card number
    const cleanCardNumber = formData.cardNumber.replace(/\s/g, '');
    if (!validateCardNumber(cleanCardNumber)) {
      setError('Invalid card number');
      return;
    }

    // Validate expiry date
    const [month, year] = formData.cardExpiry.split('/');
    const expiry = new Date(2000 + parseInt(year), parseInt(month) - 1);
    if (expiry < new Date()) {
      setError('Card has expired');
      return;
    }

    // Validate CVC
    const cvcRegex = /^\d{3,4}$/;
    if (!cvcRegex.test(formData.cardCvc)) {
      setError('Invalid CVC');
      return;
    }

    onSubmit({
      method: type,
      amount: Number(amount),
      currency: type === 'local_card' ? 'SDG' : 'USD',
      cardType,
      ...formData,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <h3 className="font-medium mb-2">Total Amount</h3>
        <p className="text-2xl font-bold text-primary">
          {formatPrice(amount, type === 'local_card' ? 'SDG' : 'USD')}
        </p>
      </div>

      <div className="space-y-4">
        <div className="relative">
          <Input
            label="Card Number"
            value={formData.cardNumber}
            onChange={handleCardNumberChange}
            placeholder="1234 5678 9012 3456"
            maxLength={19}
            required
          />
          {cardType !== 'unknown' && (
            <img
              src={CARD_LOGOS[cardType]}
              alt={`${cardType} logo`}
              className="absolute right-3 top-8 h-6"
            />
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Input
            label="Expiry Date"
            value={formData.cardExpiry}
            onChange={handleExpiryChange}
            placeholder="MM/YY"
            maxLength={5}
            required
          />
          <Input
            label="CVC"
            value={formData.cardCvc}
            onChange={(e) => setFormData({ ...formData, cardCvc: e.target.value })}
            placeholder="123"
            maxLength={4}
            required
          />
        </div>

        <Input
          label="Cardholder Name"
          value={formData.cardHolderName}
          onChange={(e) => setFormData({ ...formData, cardHolderName: e.target.value })}
          placeholder="Name as shown on card"
          required
        />
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-md p-3 flex items-start space-x-2">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <Button type="submit" className="w-full">
        <CreditCard className="h-4 w-4 mr-2" />
        Pay {formatPrice(amount, type === 'local_card' ? 'SDG' : 'USD')}
      </Button>
    </form>
  );
}