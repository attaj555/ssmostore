import React from 'react';
import { CreditCard, Building2, Globe } from 'lucide-react';
import { PaymentMethod } from '../../../lib/payment/types';

interface PaymentMethodSelectorProps {
  selectedMethod: PaymentMethod;
  onSelect: (method: PaymentMethod) => void;
}

export function PaymentMethodSelector({ selectedMethod, onSelect }: PaymentMethodSelectorProps) {
  const methods = [
    {
      id: 'bank_transfer',
      name: 'Bank Transfer',
      icon: Building2,
      description: 'Pay directly through your bank account',
    },
    {
      id: 'local_card',
      name: 'Local Card',
      icon: CreditCard,
      description: 'Pay with your Sudanese bank card',
    },
    {
      id: 'international_card',
      name: 'International Card',
      icon: Globe,
      description: 'Pay with Visa, Mastercard, or other international cards',
    },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Select Payment Method</h3>
      <div className="relative">
        <select
          value={selectedMethod}
          onChange={(e) => onSelect(e.target.value as PaymentMethod)}
          className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-primary focus:ring-primary text-base"
        >
          <option value="" disabled>Choose payment method</option>
          {methods.map(({ id, name }) => (
            <option key={id} value={id}>{name}</option>
          ))}
        </select>
      </div>

      {/* Display selected method description */}
      {selectedMethod && (
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center space-x-3">
            {React.createElement(methods.find(m => m.id === selectedMethod)?.icon || Building2, {
              className: "h-5 w-5 text-primary"
            })}
            <p className="text-sm text-gray-600">
              {methods.find(m => m.id === selectedMethod)?.description}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}