import { useState } from 'react';
import { Standard } from '../../../types';

interface UseStandardFormProps {
  standard?: Standard;
  onSubmit: (data: Partial<Standard> & { pdfFile?: File }) => void;
}

export function useStandardForm({ standard, onSubmit }: UseStandardFormProps) {
  const [formData, setFormData] = useState<Partial<Standard>>({
    title: standard?.title || '',
    number: standard?.number || '',
    category: standard?.category || '',
    description: standard?.description || '',
    price: standard?.price || 0,
    complianceType: standard?.complianceType || 'optional',
    isLatest: standard?.isLatest ?? true,
    releaseDate: standard?.releaseDate || new Date().toISOString().split('T')[0],
  });

  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormChange = (field: keyof Standard, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handlePdfChange = (file: File | null) => {
    setPdfFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pdfFile && !standard?.pdfUrl) {
      alert('Please upload a PDF file');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({ ...formData, pdfFile });
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('Failed to save standard. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    formData,
    pdfFile,
    isSubmitting,
    handleFormChange,
    handlePdfChange,
    handleSubmit,
  };
}