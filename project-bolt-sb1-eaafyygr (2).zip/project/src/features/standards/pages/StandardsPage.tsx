import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { StandardsGrid } from '../components/StandardsGrid';
import { StandardsFilter } from '../components/StandardsFilter';
import { useStore } from '../../../store/useStore';
import { Standard } from '../../../types';
import { Search } from 'lucide-react';

export function StandardsPage() {
  const { standards } = useStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    complianceType: searchParams.get('type') || '',
  });

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (filters.search) params.set('search', filters.search);
    if (filters.category) params.set('category', filters.category);
    if (filters.complianceType) params.set('type', filters.complianceType);
    setSearchParams(params);
  }, [filters, setSearchParams]);

  const filteredStandards = useMemo(() => {
    return standards.filter((standard: Standard) => {
      // Search filter
      const searchTerm = filters.search.toLowerCase().trim();
      const matchesSearch = !searchTerm || 
        standard.title.toLowerCase().includes(searchTerm) ||
        standard.number.toLowerCase().includes(searchTerm) ||
        standard.description.toLowerCase().includes(searchTerm);
      
      // Category filter
      const matchesCategory = !filters.category || 
        standard.category === filters.category;
      
      // Compliance type filter
      const matchesCompliance = !filters.complianceType || 
        standard.complianceType === filters.complianceType;

      return matchesSearch && matchesCategory && matchesCompliance;
    });
  }, [standards, filters]);

  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Browse Standards</h1>
      </div>
      
      {filteredStandards.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No standards found</h3>
          <p className="text-gray-500">
            Try adjusting your search or filters to find what you're looking for.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <StandardsFilter 
              onFilterChange={handleFilterChange}
              initialFilters={filters}
            />
          </div>
          <div className="lg:col-span-3">
            <StandardsGrid standards={filteredStandards} />
          </div>
        </div>
      )}
    </div>
  );
}