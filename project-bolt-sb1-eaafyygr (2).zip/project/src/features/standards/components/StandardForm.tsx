import React, { useState } from 'react';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { FileUpload } from '../../../components/ui/FileUpload';
import { Standard } from '../../../types';
import { useStore } from '../../../store/useStore';
import { useStandardForm } from '../hooks/useStandardForm';

interface StandardFormProps {
  standard?: Standard;
  onSubmit: (data: Partial<Standard> & { pdfFile?: File }) => void;
  onCancel?: () => void;
}

export function StandardForm({ standard, onSubmit, onCancel }: StandardFormProps) {
  const { categories } = useStore();
  const {
    formData,
    pdfFile,
    isSubmitting,
    handleFormChange,
    handlePdfChange,
    handleSubmit,
  } = useStandardForm({ standard, onSubmit });

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Standard Number"
          value={formData.number}
          onChange={(e) => handleFormChange('number', e.target.value)}
          required
        />
        <Input
          label="Title"
          value={formData.title}
          onChange={(e) => handleFormChange('title', e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            value={formData.category}
            onChange={(e) => handleFormChange('category', e.target.value)}
            required
          >
            <option value="">Select Category</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.slug}>
                {cat.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Compliance Type
          </label>
          <select
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
            value={formData.complianceType}
            onChange={(e) => handleFormChange('complianceType', e.target.value)}
            required
          >
            <option value="mandatory">Mandatory</option>
            <option value="optional">Optional</option>
          </select>
        </div>
      </div>

      <Input
        label="Description"
        value={formData.description}
        onChange={(e) => handleFormChange('description', e.target.value)}
        required
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="Price"
          type="number"
          min="0"
          step="0.01"
          value={formData.price?.toString() || ''}
          onChange={(e) => handleFormChange('price', e.target.value ? parseFloat(e.target.value) : 0)}
          required
        />
        <Input
          label="Release Date"
          type="date"
          value={formData.releaseDate?.split('T')[0]}
          onChange={(e) => handleFormChange('releaseDate', e.target.value)}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          PDF File {!standard?.pdfUrl && '*'}
        </label>
        <FileUpload
          onChange={handlePdfChange}
          value={pdfFile}
          currentFileName={standard?.pdfUrl ? `Current PDF File` : undefined}
          maxSize={20}
        />
      </div>

      <div className="flex justify-end space-x-2">
        {onCancel && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : standard ? 'Update Standard' : 'Add Standard'}
        </Button>
      </div>
    </form>
  );
}