import React from 'react';
import { Input } from '../../../components/ui/Input';
import { Button } from '../../../components/ui/Button';
import { useStore } from '../../../store/useStore';
import { Search, X } from 'lucide-react';

interface StandardsFilterProps {
  onFilterChange: (filters: {
    search: string;
    category: string;
    complianceType: string;
  }) => void;
  initialFilters: {
    search: string;
    category: string;
    complianceType: string;
  };
}

export function StandardsFilter({ onFilterChange, initialFilters }: StandardsFilterProps) {
  const { categories } = useStore();
  const [filters, setFilters] = React.useState(initialFilters);

  const handleChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleClear = () => {
    const clearedFilters = {
      search: '',
      category: '',
      complianceType: '',
    };
    setFilters(clearedFilters);
    onFilterChange(clearedFilters);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm space-y-4">
      <div className="relative">
        <Input
          placeholder="Search standards..."
          value={filters.search}
          onChange={(e) => handleChange('search', e.target.value)}
          className="pl-10"
        />
        <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Category
        </label>
        <select
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
          value={filters.category}
          onChange={(e) => handleChange('category', e.target.value)}
        >
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category.id} value={category.slug}>
              {category.name}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Type
        </label>
        <select
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
          value={filters.complianceType}
          onChange={(e) => handleChange('complianceType', e.target.value)}
        >
          <option value="">All Types</option>
          <option value="mandatory">Mandatory</option>
          <option value="optional">Optional</option>
        </select>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={handleClear}
      >
        Clear Filters
      </Button>
    </div>
  );
}