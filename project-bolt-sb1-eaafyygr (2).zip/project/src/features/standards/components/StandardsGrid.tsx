import React from 'react';
import { StandardCard } from '../../../components/StandardCard';
import { Standard } from '../../../types';

interface StandardsGridProps {
  standards: Standard[];
}

export function StandardsGrid({ standards }: StandardsGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {standards.map((standard) => (
        <StandardCard key={standard.id} standard={standard} />
      ))}
    </div>
  );
}