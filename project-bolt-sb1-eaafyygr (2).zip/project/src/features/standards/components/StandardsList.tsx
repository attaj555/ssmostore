import React, { useState } from 'react';
import { useStore } from '../../../store/useStore';
import { Button } from '../../../components/ui/Button';
import { StandardForm } from './StandardForm';
import { Standard } from '../../../types';
import { formatPrice } from '../../../lib/utils';
import { Pencil, Trash2, Plus } from 'lucide-react';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog';
import { PDFPreview } from '../../../components/ui/PDFPreview';

export function StandardsList() {
  const { standards, addStandard, updateStandard, deleteStandard } = useStore();
  const [editingStandard, setEditingStandard] = useState<Standard | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [standardToDelete, setStandardToDelete] = useState<Standard | null>(null);

  const handleAdd = async (data: Partial<Standard>) => {
    await addStandard(data);
    setIsAddingNew(false);
  };

  const handleUpdate = async (data: Partial<Standard>) => {
    if (editingStandard) {
      await updateStandard(editingStandard.id, data);
      setEditingStandard(null);
    }
  };

  const handleDelete = async () => {
    if (standardToDelete) {
      await deleteStandard(standardToDelete.id);
      setStandardToDelete(null);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6 border-b">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Standards Management</h2>
          <Button onClick={() => setIsAddingNew(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add New Standard
          </Button>
        </div>
      </div>

      {isAddingNew && (
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium mb-4">Add New Standard</h3>
          <StandardForm
            onSubmit={handleAdd}
            onCancel={() => setIsAddingNew(false)}
          />
        </div>
      )}

      {editingStandard && (
        <div className="p-6 border-b">
          <h3 className="text-lg font-medium mb-4">Edit Standard</h3>
          <StandardForm
            standard={editingStandard}
            onSubmit={handleUpdate}
            onCancel={() => setEditingStandard(null)}
          />
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Number
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Title
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                PDF
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {standards.map((standard) => (
              <tr key={standard.id}>
                <td className="px-6 py-4">{standard.number}</td>
                <td className="px-6 py-4">{standard.title}</td>
                <td className="px-6 py-4 capitalize">{standard.category}</td>
                <td className="px-6 py-4">{formatPrice(standard.price)}</td>
                <td className="px-6 py-4 capitalize">{standard.complianceType}</td>
                <td className="px-6 py-4">
                  <PDFPreview
                    url={standard.pdfUrl}
                    fileName={`${standard.number}-${standard.title}.pdf`}
                  />
                </td>
                <td className="px-6 py-4">
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      onClick={() => setEditingStandard(standard)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setStandardToDelete(standard)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmDialog
        isOpen={!!standardToDelete}
        title="Delete Standard"
        message={`Are you sure you want to delete "${standardToDelete?.title}"? This action cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={handleDelete}
        onCancel={() => setStandardToDelete(null)}
      />
    </div>
  );
}