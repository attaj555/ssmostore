import React from 'react';
import { useStore } from '../../../store/useStore';
import { formatPrice } from '../../../lib/utils';
import { FileText } from 'lucide-react';
import { ProfileSettings } from '../components/ProfileSettings';

export function ProfilePage() {
  const { user } = useStore();

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-yellow-50 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
          <p className="font-medium">Please log in to view your profile</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      <ProfileSettings />

      {user.role === 'user' && (
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-6 border-b">
            <h2 className="text-xl font-semibold">Purchase History</h2>
          </div>
          <div className="divide-y">
            {/* Purchase history items */}
          </div>
        </div>
      )}
    </div>
  );
}