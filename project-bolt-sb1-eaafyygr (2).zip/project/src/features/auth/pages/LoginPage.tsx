import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { AuthForm } from '../components/AuthForm';
import { useStore } from '../../../store/useStore';
import { Logo } from '../../../components/Logo';

export function LoginPage() {
  const { login } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(location.state?.message || '');

  const handleLogin = async (data: { email: string; password: string }) => {
    setError('');
    setSuccess('');
    
    const result = await login(data.email, data.password);
    if (result.success) {
      const returnTo = location.state?.returnTo || '/standards';
      navigate(returnTo);
    } else {
      setError(result.error || 'Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <h1 className="mt-6 text-center text-3xl font-bold text-gray-900">
          Sign in to your account
        </h1>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {error && (
            <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-100 text-green-700 rounded-md">
              {success}
            </div>
          )}

          <AuthForm type="login" onSubmit={handleLogin} />
          
          <div className="mt-6 space-y-4">
            <div className="text-sm text-center">
              <Link to="/forgot-password" className="text-primary hover:text-primary/80">
                Forgot your password?
              </Link>
            </div>
            
            <div className="text-sm text-center text-gray-600">
              Don't have an account?{' '}
              <Link to="/register" className="text-primary hover:text-primary/80">
                Sign up
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}