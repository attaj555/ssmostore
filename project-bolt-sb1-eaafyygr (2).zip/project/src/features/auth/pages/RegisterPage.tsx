import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthForm } from '../components/AuthForm';
import { useStore } from '../../../store/useStore';

export function RegisterPage() {
  const navigate = useNavigate();
  const { setUser } = useStore();

  const handleRegister = async (data: { email: string; password: string; name?: string }) => {
    // In a real app, this would make an API call
    setUser({
      id: Math.random().toString(36).substr(2, 9),
      email: data.email,
      name: data.name || 'User',
      role: 'user',
    });
    navigate('/standards');
  };

  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-2xl font-bold text-center mb-8">Create an Account</h1>
      <AuthForm type="register" onSubmit={handleRegister} />
      <p className="mt-4 text-center text-sm text-gray-600">
        Already have an account?{' '}
        <Link to="/login" className="text-primary hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}