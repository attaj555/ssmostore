import React from 'react';
import { Trash2 } from 'lucide-react';
import { formatPrice } from '../../../lib/utils';
import { Button } from '../../../components/ui/Button';
import { Standard } from '../../../types';

interface CartItemProps {
  standard: Standard;
  quantity: number;
  onRemove: () => void;
  onUpdateQuantity: (quantity: number) => void;
}

export function CartItem({
  standard,
  quantity,
  onRemove,
  onUpdateQuantity,
}: CartItemProps) {
  return (
    <div className="flex items-center py-4 border-b">
      <div className="flex-1">
        <h3 className="font-medium">{standard.title}</h3>
        <p className="text-sm text-gray-500">Standard No: {standard.number}</p>
      </div>
      <div className="flex items-center space-x-4">
        <input
          type="number"
          min="1"
          value={quantity}
          onChange={(e) => onUpdateQuantity(parseInt(e.target.value, 10))}
          className="w-16 rounded-md border-gray-300"
        />
        <span className="font-medium">{formatPrice(standard.price * quantity)}</span>
        <Button variant="outline" size="sm" onClick={onRemove}>
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}