import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../store/useStore';
import { CartItem } from '../components/CartItem';
import { Button } from '../../../components/ui/Button';
import { formatPrice } from '../../../lib/utils';
import { ShoppingCart, LogIn } from 'lucide-react';

export function CartPage() {
  const navigate = useNavigate();
  const { cart, standards, removeFromCart, updateCartItemQuantity, user } = useStore();

  const cartItems = cart.map((item) => ({
    ...item,
    standard: standards.find((s) => s.id === item.standardId)!,
  }));

  const total = cartItems.reduce(
    (sum, item) => sum + item.standard.price * item.quantity,
    0
  );

  const handleUpdateQuantity = (standardId: string, quantity: number) => {
    if (quantity < 1) return;
    updateCartItemQuantity(standardId, quantity);
  };

  const handleCheckout = () => {
    if (!user) {
      navigate('/login', { state: { returnTo: '/checkout' } });
    } else {
      navigate('/checkout');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Shopping Cart</h1>
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <ShoppingCart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 mb-4">Your cart is empty</p>
          <Button onClick={() => navigate('/standards')}>
            Browse Standards
          </Button>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {cartItems.map((item) => (
              <CartItem
                key={item.standardId}
                standard={item.standard}
                quantity={item.quantity}
                onRemove={() => removeFromCart(item.standard.id)}
                onUpdateQuantity={(quantity) => handleUpdateQuantity(item.standard.id, quantity)}
              />
            ))}
          </div>
          <div className="mt-8 space-y-4">
            <div className="flex justify-between text-lg font-medium">
              <span>Total</span>
              <span>{formatPrice(total)}</span>
            </div>
            <Button className="w-full" onClick={handleCheckout}>
              {user ? (
                'Proceed to Checkout'
              ) : (
                <>
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign in to Checkout
                </>
              )}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}