import { StateCreator } from 'zustand';
import { CartItem } from '../../types';
import { StoreState } from '../types';

export const createCartSlice: StateCreator<StoreState> = (set, get) => ({
  addToCart: (standardId) => set((state) => {
    const existingItem = state.cart.find(item => item.standardId === standardId);
    if (existingItem) {
      return {
        cart: state.cart.map(item =>
          item.standardId === standardId
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ),
      };
    }
    return {
      cart: [...state.cart, { standardId, quantity: 1 }],
    };
  }),

  removeFromCart: (standardId) => set((state) => ({
    cart: state.cart.filter(item => item.standardId !== standardId)
  })),

  updateCartItemQuantity: (standardId, quantity) => set((state) => ({
    cart: state.cart.map(item =>
      item.standardId === standardId ? { ...item, quantity } : item
    )
  })),

  clearCart: () => set({ cart: [] }),

  isInCart: (standardId) => get().cart.some(item => item.standardId === standardId),
});