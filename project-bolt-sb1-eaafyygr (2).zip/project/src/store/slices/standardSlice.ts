import { StateCreator } from 'zustand';
import { Standard } from '../../types';
import { StoreState } from '../types';

export const createStandardSlice: StateCreator<StoreState> = (set) => ({
  addStandard: (standard) => set((state) => ({
    standards: [...state.standards, { ...standard, id: Math.random().toString(36).substr(2, 9) }]
  })),

  updateStandard: (id, standard) => set((state) => ({
    standards: state.standards.map(s => s.id === id ? { ...s, ...standard } : s)
  })),

  deleteStandard: (id) => set((state) => ({
    standards: state.standards.filter(s => s.id !== id)
  })),
});