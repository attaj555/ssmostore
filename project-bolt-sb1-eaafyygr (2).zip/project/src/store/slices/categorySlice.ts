import { StateCreator } from 'zustand';
import { Category } from '../../types';
import { StoreState } from '../types';

export const createCategorySlice: StateCreator<StoreState> = (set) => ({
  addCategory: (category) => set((state) => ({
    categories: [...state.categories, { ...category, id: Math.random().toString(36).substr(2, 9) }]
  })),

  updateCategory: (id, category) => set((state) => ({
    categories: state.categories.map(c => c.id === id ? { ...c, ...category } : c)
  })),

  deleteCategory: (id) => set((state) => ({
    categories: state.categories.filter(c => c.id !== id)
  })),
});