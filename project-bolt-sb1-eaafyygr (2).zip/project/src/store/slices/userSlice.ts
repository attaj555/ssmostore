import { StateCreator } from 'zustand';
import { User } from '../../types';
import { StoreState } from '../types';
import { superAdmins } from '../data/users';

export const createUserSlice: StateCreator<StoreState> = (set, get) => ({
  setUser: (user) => set({ user }),

  login: async (email, password) => {
    const superAdmin = superAdmins.find(
      admin => admin.email.toLowerCase() === email.toLowerCase()
    );
    
    if (superAdmin && password === '123') {
      set({ user: superAdmin });
      return { success: true };
    }

    const { admins } = get();
    const admin = admins.find(
      admin => admin.email.toLowerCase() === email.toLowerCase()
    );
    
    if (admin && password === '123') {
      set({ user: admin });
      return { success: true };
    }

    if (email && password) {
      if (email.toLowerCase().endsWith('@ssmo.gov.sd')) {
        return {
          success: false,
          error: 'Please contact a super admin to get admin access'
        };
      }

      const user = {
        id: Math.random().toString(36).substr(2, 9),
        name: email.split('@')[0],
        email,
        role: 'user' as const,
        createdAt: new Date().toISOString()
      };

      set({ user });
      return { success: true };
    }

    return { success: false, error: 'Invalid email or password' };
  },

  addAdmin: async (admin) => {
    if (!admin.email.endsWith('@ssmo.gov.sd') && admin.email !== 'attaj555@gmail.com') {
      throw new Error('Admin email must be a valid SSMO email address');
    }

    set((state) => ({
      admins: [...state.admins, {
        id: Math.random().toString(36).substr(2, 9),
        ...admin,
        role: 'admin' as const,
        createdAt: new Date().toISOString()
      }]
    }));
  },

  removeAdmin: async (id) => {
    set((state) => ({
      admins: state.admins.filter(admin => admin.id !== id)
    }));
  },

  updateUserProfile: async (data) => {
    const { user } = get();
    if (!user) throw new Error('No user logged in');

    if (data.newPassword) {
      if (!data.currentPassword) {
        throw new Error('Current password is required to change password');
      }
      if (data.currentPassword !== '123') {
        throw new Error('Current password is incorrect');
      }
    }

    set({
      user: {
        ...user,
        name: data.name,
        updatedAt: new Date().toISOString(),
      }
    });
  },
});