import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Standard, User, CartItem, Category, Bank } from '../types';
import { sampleStandards } from './data/standards';
import { superAdmins } from './data/users';
import { sampleCategories } from './data/categories';
import { StoreState } from './types';
import { createCategorySlice } from './slices/categorySlice';
import { createStandardSlice } from './slices/standardSlice';
import { createUserSlice } from './slices/userSlice';
import { createCartSlice } from './slices/cartSlice';

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      ...createCategorySlice(set, get),
      ...createStandardSlice(set, get),
      ...createUserSlice(set, get),
      ...createCartSlice(set, get),
      
      // Initial state
      user: null,
      admins: [],
      standards: sampleStandards,
      categories: sampleCategories,
      cart: [],
      banks: [],
    }),
    {
      name: 'ssmo-store',
      partialize: (state) => ({
        cart: state.cart,
        admins: state.admins,
      }),
    }
  )
);