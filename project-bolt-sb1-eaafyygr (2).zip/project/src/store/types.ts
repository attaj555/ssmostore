import { Standard, User, CartItem, Category, Bank } from '../types';

export interface StoreState {
  user: User | null;
  admins: User[];
  standards: Standard[];
  categories: Category[];
  cart: CartItem[];
  banks: Bank[];
  
  // Category actions
  addCategory: (category: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, category: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  // Standard actions
  addStandard: (standard: Omit<Standard, 'id'>) => void;
  updateStandard: (id: string, standard: Partial<Standard>) => void;
  deleteStandard: (id: string) => void;

  // User actions
  setUser: (user: User | null) => void;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  addAdmin: (admin: { email: string; name: string }) => Promise<void>;
  removeAdmin: (id: string) => Promise<void>;
  updateUserProfile: (data: {
    name: string;
    currentPassword?: string;
    newPassword?: string;
  }) => Promise<void>;

  // Cart actions
  addToCart: (standardId: string) => void;
  removeFromCart: (standardId: string) => void;
  updateCartItemQuantity: (standardId: string, quantity: number) => void;
  clearCart: () => void;
  isInCart: (standardId: string) => boolean;
}