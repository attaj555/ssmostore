import { Category } from '../../types';

export const sampleCategories: Category[] = [
  {
    id: '1',
    name: 'Electrical',
    slug: 'electrical',
    description: 'Standards for electrical equipment and installations',
  },
  {
    id: '2',
    name: 'Food Safety',
    slug: 'food',
    description: 'Standards for food processing and safety',
  },
  {
    id: '3',
    name: 'Mechanical',
    slug: 'mechanical',
    description: 'Standards for mechanical equipment and processes',
  },
];