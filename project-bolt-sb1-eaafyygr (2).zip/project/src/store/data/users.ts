import { User } from '../../types';

export const superAdmins: User[] = [
  {
    id: 'super_admin_1',
    name: 'Super Admin',
    email: 'attaj555@gmail.com',
    role: 'super_admin',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
  {
    id: 'super_admin_2',
    name: 'SSMO Super Admin',
    email: 'storeadmin@ssmo.gov.sd',
    role: 'super_admin',
    createdAt: '2024-01-01T00:00:00.000Z',
  },
];

export const initialAdmins: User[] = [];